package eu.esmo.gateway.acm.rest_api.controllers.attributes;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/

import eu.esmo.gateway.acm.rest_api.domain.MsResponse;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-11-29T14:30:50.899Z")

@Api(value = "attributes", description = "the attributes API")
public interface AttributesApi {

//	@ApiOperation(value = "Process the received request, communicate with Session Manager and handle the attribute retrieval and aggregation. Called by SP Connector, GW Connector.", nickname = "requestAttributes", notes = "", response = MsResponse.class, tags={ "Attribute Collection Manager", })
//    @ApiResponses(value = { 
//        @ApiResponse(code = 200, message = "OK", response = MsResponse.class) })
//    @RequestMapping(value = "/requestGet",
////        produces = { "application/json" }, 
////        consumes = { "application/json" },
//        method = RequestMethod.GET)
//    String requestAttributes2(@ApiParam(value = "References the session and attribute list(s) in the Session Manager" ,required=true )  @Valid String msToken, Model model);
	
	@GetMapping("/requestGet")
	String requestAttributes2(String sessionId, Model model);
	
	@GetMapping("/requestSessionId")
	String requestAttributes3(String token);
	
	@GetMapping("/requestAllVbles")
	String requestAllVbles(String sessionId);
	
	@ApiOperation(value = "Process the received request, communicate with Session Manager and handle the attribute retrieval and aggregation. Called by SP Connector, GW Connector.", nickname = "requestAttributes", notes = "", response = MsResponse.class, tags={ "Attribute Collection Manager", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = MsResponse.class) })
    //@RequestMapping(value = "/attributes/request",
    @RequestMapping(value = "/request",
        produces = { "application/json" }, 
        consumes = { "application/json","application/x-www-form-urlencoded"},
        method = RequestMethod.POST)
    String requestAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager" ,required=true )  @Valid @RequestBody String msToken, Model model);


    @ApiOperation(value = "Handle DSA responses on the call back after the Attribute Set is retrieved from an AP (directly connected to the Gateway or via a proxy terminating Gateway). Called by AP Connector.", nickname = "responseAttributes", notes = "", response = MsResponse.class, tags={ "Attribute Collection Manager", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = MsResponse.class) })
    //@RequestMapping(value = "/attributes/response",
    @RequestMapping(value = "/response",
        produces = { "application/json" }, 
        consumes = { "application/json","application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    String responseAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager." ,required=true )  @Valid @RequestBody String msToken, Model model);

	
    @ApiOperation(value = "HelloWorld", nickname = "HelloWorld", notes = "", response = MsResponse.class, tags={ "Attribute Collection Manager", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = MsResponse.class) })
    @RequestMapping(value = "/helloworld/",
        produces = { "application/json" }, 
        //consumes = { "application/json" },
        method = RequestMethod.GET)
    ResponseEntity<MsResponse> helloWord();

    
}
