package eu.esmo.gateway.acm.domain;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.util.*;
import org.springframework.stereotype.Component;

@Component
public class AcmStates 
{
	//Hay que revisar esta clase porque puede haber multiples ACMs y la informaci�n de estado se tiene 
	// que guardar en el SessionManager
	
	List<AcmState> acmStatesList= new ArrayList<AcmState>();
	public void addNewState( String sessionId)
	{
		AcmState acmState = new AcmState(sessionId);
		acmStatesList.add(acmState);
	}
	
	public void addSpRequest(String sessionId, AttributeSet spRequest)
	{
		for (AcmState acmState: acmStatesList)
		{
			if (acmState.getSessionId().equalsIgnoreCase( sessionId))
			{	
				acmState.setSpRequest(spRequest);
				break;
			}
			
		}
	}
	

	class AcmState
	{
		private String sessionId;
	
		public AcmState(String sessionID)
		{
			this.sessionId = sessionID;
		}
		public String getSessionId() {
			return sessionId;
		}
		
		private AttributeSet spRequest;
		public AttributeSet getSpRequest() {
			return spRequest;
		}

		public void setSpRequest(AttributeSet spRequest) {
			this.spRequest = spRequest;
		}
	}
}
