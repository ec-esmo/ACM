package eu.esmo.gateway.acm.domain;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import com.fasterxml.jackson.annotation.JsonAlias;

import eu.esmo.gateway.acm.domain.ApiCallType;
import eu.esmo.gateway.acm.domain.ApiClassEnum;
import eu.esmo.gateway.acm.domain.ApiConnectionType;
import eu.esmo.gateway.acm.domain.MSConfigurationResponse.MicroService;
import eu.esmo.gateway.acm.domain.MSConfigurationResponse.PublishedAPI;

/**
 *
 * @author nikos
 */
public class MSConfigurationResponse {

    private MicroService[] ms;

    public MSConfigurationResponse() {
    }

    public MSConfigurationResponse(MicroService[] ms) {
        this.ms = ms;
    }

    public MicroService[] getMs() {
        return ms;
    }

    public void setMs(MicroService[] ms) {
        this.ms = ms;
    }

    //static is needed for jackson
    public static class MicroService {

        @JsonAlias({"msId", "msID"})
        private String msId;
        private String[] authorizedMicroservices; // List of ms identifiers that will be authorised to contact this microservice (will be used by the SM when validating a token).
        private String msType;
        private String rsaPublicKeyBinary;
        private PublishedAPI[] publishedAPI;

        public MicroService(String msID, String msType, String rsaPublicKeyBinary, PublishedAPI[] publishedAPI, String[] authorizedMicroservices) {
            this.msId = msID;
            this.msType = msType;
            this.rsaPublicKeyBinary = rsaPublicKeyBinary;
            this.publishedAPI = publishedAPI;
            this.authorizedMicroservices= authorizedMicroservices;
        }

        public String[] getAuthorizedMicroservices() {
            return authorizedMicroservices;
        }

        public void setAuthorizedMicroservices(String[] authorizedMicroservices) {
            this.authorizedMicroservices = authorizedMicroservices;
        }

        
        public MicroService() {
        }

        public String getMsId() {
            return msId;
        }

        public void setMsId(String msId) {
            this.msId = msId;
        }

        public String getMsType() {
            return msType;
        }

        public void setMsType(String msType) {
            this.msType = msType;
        }

        public String getRsaPublicKeyBinary() {
            return rsaPublicKeyBinary;
        }

        public void setRsaPublicKeyBinary(String rsaPublicKeyBinary) {
            this.rsaPublicKeyBinary = rsaPublicKeyBinary;
        }

        public PublishedAPI[] getPublishedAPI() {
            return publishedAPI;
        }

        public void setPublishedAPI(PublishedAPI[] publishedAPI) {
            this.publishedAPI = publishedAPI;
        }

    }

    //static is needed for jackson
    public static class PublishedAPI {

        private ApiClassEnum apiClass;
        private ApiCallType apiCall;
        private ApiConnectionType apiConnectionType;
        private String apiEndpoint;

        public PublishedAPI() {
        }

        public PublishedAPI(ApiClassEnum apiClass, ApiCallType apiCall, ApiConnectionType apiConnectionType, String url) {
            this.apiClass = apiClass;
            this.apiCall = apiCall;
            this.apiConnectionType = apiConnectionType;
            this.apiEndpoint = url;
        }

        public ApiClassEnum getApiClass() {
            return apiClass;
        }

        public void setApiClass(ApiClassEnum apiClass) {
            this.apiClass = apiClass;
        }

        public ApiCallType getApiCall() {
            return apiCall;
        }

        public void setApiCall(ApiCallType apiCall) {
            this.apiCall = apiCall;
        }

        public ApiConnectionType getApiConnectionType() {
            return apiConnectionType;
        }

        public void setApiConnectionType(ApiConnectionType apiConnectionType) {
            this.apiConnectionType = apiConnectionType;
        }

        public String getApiEndpoint() {
            return apiEndpoint;
        }

        public void setApiEndpoint(String apiEndpoint) {
            this.apiEndpoint = apiEndpoint;
        }

    }

}

