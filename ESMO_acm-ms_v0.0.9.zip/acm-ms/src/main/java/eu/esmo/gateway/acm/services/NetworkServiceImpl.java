package eu.esmo.gateway.acm.services;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.acm.domain.SessionMngrResponse;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import org.apache.commons.httpclient.NameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

/**
 *
 * @author nikos
 */
public class NetworkServiceImpl implements NetworkService 
{
	private final HttpSignatureService sigServ;
    private final static Logger LOG = LoggerFactory.getLogger(NetworkServiceImpl.class);

    public NetworkServiceImpl(HttpSignatureService sigServ) {
        this.sigServ = sigServ;
    }
    
    @Override
   	public String sendGetURIParams(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt)
   			throws IOException, NoSuchAlgorithmException 
   	{
   		Date date = new Date();
           SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
           formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
           String nowDate = formatter.format(date);
           String requestId = UUID.randomUUID().toString();
           UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
           Map<String, String> map = new HashMap();
           if (urlParameters != null) {
              
               urlParameters.stream().forEach(nameVal -> {
                   map.put(nameVal.getName(), nameVal.getValue());
               });
           }

           RestTemplate restTemplate = new RestTemplate();
           HttpHeaders requestHeaders = new HttpHeaders();
           String host = hostUrl.replace("http://", "").replace("https://", "");
           byte[] digest = MessageDigest.getInstance("SHA-256").digest("".getBytes());
           try {
               requestHeaders.add("host", host);
               requestHeaders.add("original-date", nowDate);
               requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digest)));
               requestHeaders.add("x-request-id", requestId);
               URL url = new URL(builder.buildAndExpand(map).toUriString());

               requestHeaders.add("authorization", sigServ.generateSignature(host, "GET", url.getPath(), null, "application/json", requestId));

           } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
               LOG.error("could not generate signature!!");
               LOG.error(e.getMessage());
           }

           HttpEntity entity = new HttpEntity(requestHeaders);
           try {
               ResponseEntity<String> response = restTemplate.exchange(
                       builder.buildAndExpand(map).toUriString(), HttpMethod.GET, entity, String.class);
               return response.getBody();
           } catch (RestClientException e) {
           	LOG.error("A SECOND trial!");
               LOG.error(e.getMessage());
               if (attempt < 2) {
                   return sendGetURIParams(hostUrl, uri,
                           urlParameters, attempt + 1);
               }
           }
           return null;
   	}

	@Override
	public String sendGet(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt)
			throws IOException, NoSuchAlgorithmException 
	{
		Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        String nowDate = formatter.format(date);
        String requestId = UUID.randomUUID().toString();
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
        if (urlParameters != null) {
            Map<String, String> map = new HashMap();
            urlParameters.stream().forEach(nameVal -> {
                map.put(nameVal.getName(), nameVal.getValue());
                builder.queryParam(nameVal.getName(), nameVal.getValue());
            });
        }

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        String host = hostUrl.replace("http://", "").replace("https://", "");
        byte[] digest = MessageDigest.getInstance("SHA-256").digest("".getBytes());
        try {
            requestHeaders.add("host", host);
            requestHeaders.add("original-date", nowDate);
            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digest)));
            requestHeaders.add("x-request-id", requestId);
            URL url = new URL(builder.toUriString());

            requestHeaders.add("authorization", sigServ.generateSignature(host, "GET", url.getPath() + "?" + url.getQuery(), null, "application/x-www-form-urlencoded", requestId));
        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            LOG.error("could not generate signature!!");
            LOG.error(e.getMessage());
        }

        HttpEntity entity = new HttpEntity(requestHeaders);
        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    builder.toUriString(), HttpMethod.GET, entity, String.class);
            return response.getBody();
        } catch (RestClientException e) {
            if (attempt < 2) {
                return sendGet(hostUrl, uri,
                        urlParameters, attempt + 1);
            }
        }
        return null;
	}

	@Override
	public String sendPostForm(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt)
			throws IOException, NoSuchAlgorithmException 
	{
		Map<String, String> map = new HashMap();
        MultiValueMap<String, String> multiMap = new LinkedMultiValueMap<>();

        urlParameters.stream().forEach(nameVal -> {
            map.put(nameVal.getName(), nameVal.getValue());
            multiMap.add(nameVal.getName(), nameVal.getValue());
        });

        String requestId = UUID.randomUUID().toString();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String host = hostUrl.replace("http://", "").replace("https://", "");

        try {
            headers.add("authorization", sigServ.generateSignature(host, "POST", uri, null, "application/x-www-form-urlencoded", requestId));
            Date date = new Date();
            byte[] digestBytes;
            //only when the request is json encoded are the post params added to the body of the request
            // else they eventually become encoded to the url
            digestBytes = MessageDigest.getInstance("SHA-256").digest("".getBytes());
            addHeaders(headers, host, date, digestBytes, uri, requestId);

        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            LOG.error("could not generate signature!!");
            LOG.error(e.getMessage());
        }

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(multiMap, headers);
        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                    hostUrl + uri, request, String.class);
            LOG.info("request ok (not retry)");
            return response.getBody();
        } catch (RestClientException e) {
            LOG.info("request failed will retry");
            if (attempt < 2) {
                return sendPostForm(hostUrl, uri,
                        urlParameters, attempt + 1);
            }
        }
        return null;
	}

	@Override
	public String sendPostBody(String hostUrl, String uri, Object postBody, String contentType, int attempt)
			throws IOException, NoSuchAlgorithmException 
	{
		Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        String nowDate = formatter.format(date);
        String requestId = UUID.randomUUID().toString();

        ObjectMapper mapper = new ObjectMapper();
        String updateString = mapper.writeValueAsString(postBody);
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()); // post parameters are added as uri parameters not in the body when form-encoding
        String host = hostUrl.replace("http://", "").replace("https://", "");
        try {
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.add("authorization", sigServ.generateSignature(host, "POST", "/sm/updateSessionData", postBody, "application/json;charset=UTF-8", requestId));
            requestHeaders.add("host", hostUrl);
            requestHeaders.add("original-date", nowDate);
            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()))));
            requestHeaders.add("x-request-id", requestId);
            requestHeaders.setContentType(MediaType.APPLICATION_JSON);
            requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<Object> requestEntity = new HttpEntity<>(postBody, requestHeaders);
            try {
                ResponseEntity<String> response
                        = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, requestEntity,
                                String.class);
                LOG.info("request ok (not retry)");
                return response.getBody();
            } catch (RestClientException e) {
                LOG.info("request failed will retry");
                if (attempt < 2) {
                    return sendPostBody(hostUrl, uri, postBody, contentType, attempt + 1);
                }
            }
        } catch (UnrecoverableKeyException e) {
            LOG.info(e.getMessage());
        } catch (KeyStoreException e) {
            LOG.info(e.getMessage());
        } catch (UnsupportedEncodingException e) {
            LOG.info(e.getMessage());
        }
        return null;

	}
	
	@Override
	public SessionMngrResponse sendPostBodySMResponse(String hostUrl, String uri, Object postBody, String contentType, int attempt)
			throws IOException, NoSuchAlgorithmException 
	{
		Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        String nowDate = formatter.format(date);
        String requestId = UUID.randomUUID().toString();

        ObjectMapper mapper = new ObjectMapper();
        String updateString = mapper.writeValueAsString(postBody);
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()); // post parameters are added as uri parameters not in the body when form-encoding
        String host = hostUrl.replace("http://", "").replace("https://", "");
        try {
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.add("authorization", sigServ.generateSignature(host, "POST", "/sm/updateSessionData", postBody, "application/json;charset=UTF-8", requestId));
            requestHeaders.add("host", hostUrl);
            requestHeaders.add("original-date", nowDate);
            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()))));
            requestHeaders.add("x-request-id", requestId);
            requestHeaders.setContentType(MediaType.APPLICATION_JSON);
            requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<Object> requestEntity = new HttpEntity<>(postBody, requestHeaders);
            try {
                ResponseEntity<SessionMngrResponse> response
                        = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, requestEntity,
                        		SessionMngrResponse.class);
                LOG.info("request ok (not retry)");
                return response.getBody();
            } catch (RestClientException e) {
                LOG.info("request failed will retry");
                if (attempt < 2) {
                    return sendPostBodySMResponse(hostUrl, uri, postBody, contentType, attempt + 1);
                }
            }
        } catch (UnrecoverableKeyException e) {
            LOG.info(e.getMessage());
        } catch (KeyStoreException e) {
            LOG.info(e.getMessage());
        } catch (UnsupportedEncodingException e) {
            LOG.info(e.getMessage());
        }
        return null;

	}

	@Override
	public SessionMngrResponse sendPostFormSMResponse(String hostUrl, String uri, List<NameValuePair> urlParameters,
			int attempt) throws IOException, NoSuchAlgorithmException 
	{
		Map<String, String> map = new HashMap();
        MultiValueMap<String, String> multiMap = new LinkedMultiValueMap<>();

        urlParameters.stream().forEach(nameVal -> {
            map.put(nameVal.getName(), nameVal.getValue());
            multiMap.add(nameVal.getName(), nameVal.getValue());
        });

        String requestId = UUID.randomUUID().toString();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String host = hostUrl.replace("http://", "").replace("https://", "");

        try {
            headers.add("authorization", sigServ.generateSignature(host, "POST", uri, null, "application/x-www-form-urlencoded", requestId));
            Date date = new Date();
            byte[] digestBytes;
            //only when the request is json encoded are the post params added to the body of the request
            // else they eventually become encoded to the url
            digestBytes = MessageDigest.getInstance("SHA-256").digest("".getBytes());
            addHeaders(headers, host, date, digestBytes, uri, requestId);

        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            LOG.error("could not generate signature!!");
            LOG.error(e.getMessage());
        }

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(multiMap, headers);
        try {
//            ResponseEntity<String> response = restTemplate.postForEntity(
//                    hostUrl + uri, request, String.class);
            ResponseEntity<SessionMngrResponse> response = restTemplate.postForEntity(
                  hostUrl + uri, request, SessionMngrResponse.class);
            LOG.info("request ok (not retry)");
            return response.getBody();
        } catch (RestClientException e) {
            LOG.info("request failed will retry");
            if (attempt < 2) {
                return sendPostFormSMResponse(hostUrl, uri,
                        					  urlParameters, attempt + 1);
            }
            LOG.info("2 EXCEPTION(sendPostFormSMResponse): "+e.getMessage());
        }
        return null;	
	}

	@Override
	public SessionMngrResponse sendGetSMResponse(String hostUrl, String uri, List<NameValuePair> urlParameters,
												 int attempt) throws IOException, NoSuchAlgorithmException 
	{
		Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        String nowDate = formatter.format(date);
        LOG.info("addHeaders DATE:"+nowDate);
//      Date date2 = new Date();
//      SimpleDateFormat formatter2 = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z",Locale.ENGLISH);
//      String nowDate2 = formatter2.format(date);
//      LOG.info("addHeaders2 DATE:"+nowDate2);
//      nowDate= nowDate2;

        
        String requestId = UUID.randomUUID().toString();
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
        if (urlParameters != null) {
            Map<String, String> map = new HashMap();
            urlParameters.stream().forEach(nameVal -> {
                map.put(nameVal.getName(), nameVal.getValue());
                builder.queryParam(nameVal.getName(), nameVal.getValue());
            });
        }

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        String host = hostUrl.replace("http://", "").replace("https://", "");
        byte[] digest = MessageDigest.getInstance("SHA-256").digest("".getBytes());
        try {
            requestHeaders.add("host", host);
            requestHeaders.add("original-date", nowDate);
            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digest)));
            requestHeaders.add("x-request-id", requestId);
            URL url = new URL(builder.toUriString());

            requestHeaders.add("authorization", sigServ.generateSignature(host, "GET", url.getPath() + "?" + url.getQuery(), null, "application/x-www-form-urlencoded", requestId));
        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            LOG.error("could not generate signature!!");
            LOG.error(e.getMessage());
        }

        HttpEntity entity = new HttpEntity(requestHeaders);
        try {
            ResponseEntity<SessionMngrResponse> response = restTemplate.exchange(
                    builder.toUriString(), HttpMethod.GET, entity, SessionMngrResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            if (attempt < 2) {
                return sendGetSMResponse(hostUrl, uri,
                        				 urlParameters, attempt + 1);
            }
            LOG.info("2 EXCEPTION(sendGetSMResponse): "+e.getMessage());
        }
        return null;
	}

	
	private void addHeaders(HttpHeaders headers, String host, Date date, byte[] digestBytes, String uri, String requestId) throws NoSuchAlgorithmException 
	{
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z", Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        String nowDate = formatter.format(date);
        LOG.info("addHeaders DATE:"+nowDate);
        headers.add("host", host);
        headers.add("original-date", nowDate);
        headers.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digestBytes)));
        headers.add("x-request-id", requestId);
    }

	

//    private HttpSignatureService sigServ;
//    private final static Logger LOG = LoggerFactory.getLogger(NetworkServiceImpl.class);
//
//    public NetworkServiceImpl(HttpSignatureService sigServ) {
//        this.sigServ = sigServ;
//    }
//
//    @Override
//    public String sendPostBody(String hostUrl, String uri, Object postBody, String contentType) throws IOException, NoSuchAlgorithmException {
//
//        Date date = new Date();
//        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z",Locale.ENGLISH);
//        String nowDate = formatter.format(date);
//        String requestId = UUID.randomUUID().toString();
//
//        ObjectMapper mapper = new ObjectMapper();
//        String updateString = mapper.writeValueAsString(postBody);
//        System.out.println("NW.postBody:<"+postBody+">");
//        System.out.println("NW.postBody:<"+postBody.toString()+">");
//        System.out.println("NW.updateString:<"+updateString+">");
//        //postBody = updateString;//�?
//        byte[] digest = MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()); // post parameters are added as uri parameters not in the body when form-encoding
//        String host = hostUrl.replace("http://", "").replace("https://", "");
//        try {
//            HttpHeaders requestHeaders = new HttpHeaders();
//            requestHeaders.add("authorization", sigServ.generateSignature(host, "POST", "/sm/updateSessionData", postBody, "application/json;charset=UTF-8", requestId));
//            requestHeaders.add("host", hostUrl);
//            requestHeaders.add("original-date", nowDate);
//            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(MessageDigest.getInstance("SHA-256").digest(updateString.getBytes()))));
//            //requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(MessageDigest.getInstance("SHA-256").digest(postBody.toString().getBytes()))));
//            requestHeaders.add("x-request-id", requestId);
//            requestHeaders.setContentType(MediaType.APPLICATION_JSON);
//            requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
//            RestTemplate restTemplate = new RestTemplate();
//            HttpEntity<Object> requestEntity = new HttpEntity<>(postBody, requestHeaders);
//            ResponseEntity<String> response
//                    = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, requestEntity,
//                            String.class);
//            return response.getBody();
//        } catch (Exception e) {
//        	e.printStackTrace();
//            LOG.info(e.getMessage());
//        }
//        return null;
//    }
//
//    @Override
//    public String sendPostForm(String hostUrl, String uri,
//            List<NameValuePair> urlParameters) throws IOException, NoSuchAlgorithmException {
//
//        Map<String, String> map = new HashMap();
//        MultiValueMap<String, String> multiMap = new LinkedMultiValueMap<>();
//
//        urlParameters.stream().forEach(nameVal -> {
//            map.put(nameVal.getName(), nameVal.getValue());
//            multiMap.add(nameVal.getName(), nameVal.getValue());
//        });
//
//        String requestId = UUID.randomUUID().toString();
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//
//        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//        String host = hostUrl.replace("http://", "").replace("https://", "");
//
//        try {
//            headers.add("authorization", sigServ.generateSignature(host, "POST", uri, null, "application/x-www-form-urlencoded", requestId));
//            Date date = new Date();
//            
//            byte[] digestBytes;
//            //only when the request is json encoded are the post params added to the body of the request
//            // else they eventually become encoded to the url
//            digestBytes = MessageDigest.getInstance("SHA-256").digest("".getBytes());
//            addHeaders(headers, host, date, digestBytes, uri, requestId);
//
//        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
//            LOG.error("could not generate signature!!");
//            LOG.error(e.getMessage());
//        }
//
//        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(multiMap, headers);
//        ResponseEntity<String> response = restTemplate.postForEntity(
//                hostUrl + uri, request, String.class);
//
//        assert (response.getStatusCode().equals(HttpStatus.CREATED) || response.getStatusCode().equals(HttpStatus.OK));
//        return response.getBody();
//    }
//    
//    @Override
//    public SessionMngrResponse sendPostFormSMResponse(String hostUrl, String uri, List<NameValuePair> urlParameters)
//    			throws IOException, NoSuchAlgorithmException {
//
//        Map<String, String> map = new HashMap();
//        MultiValueMap<String, String> multiMap = new LinkedMultiValueMap<>();
//
//        urlParameters.stream().forEach(nameVal -> {
//            map.put(nameVal.getName(), nameVal.getValue());
//            multiMap.add(nameVal.getName(), nameVal.getValue());
//        });
//
//        String requestId = UUID.randomUUID().toString();
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//
//        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//        String host = hostUrl.replace("http://", "").replace("https://", "");
//
//        try {
//            headers.add("authorization", sigServ.generateSignature(host, "POST", uri, null, "application/x-www-form-urlencoded", requestId));
//            Date date = new Date();
//            
//            byte[] digestBytes;
//            //only when the request is json encoded are the post params added to the body of the request
//            // else they eventually become encoded to the url
//            digestBytes = MessageDigest.getInstance("SHA-256").digest("".getBytes());
//            addHeaders(headers, host, date, digestBytes, uri, requestId);
//
//        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
//            LOG.error("could not generate signature!!");
//            LOG.error(e.getMessage());
//        }
//
//        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(multiMap, headers);
////        ResponseEntity<String> stResponse = restTemplate.postForEntity(
////                hostUrl + uri, request, String.class);
////        System.out.println("stResponse:"+stResponse);
////        
////        ResponseEntity<SessionMngrResponse> response2 = restTemplate.exchange(
////                hostUrl + uri,HttpMethod.POST, request, SessionMngrResponse.class);
////        
////        System.out.println("response2:"+response2.toString());
//        ResponseEntity<SessionMngrResponse> response = restTemplate.postForEntity(
//                hostUrl + uri, request, SessionMngrResponse.class);
//
//        assert (response.getStatusCode().equals(HttpStatus.CREATED) || response.getStatusCode().equals(HttpStatus.OK));
//        return response.getBody();
//    }
//
//    @Override
//    public String sendGet(String hostUrl, String uri,
//            List<NameValuePair> urlParameters) throws IOException, NoSuchAlgorithmException {
//
//        Date date = new Date();
//        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z",Locale.ENGLISH);
//        String nowDate = formatter.format(date);
//        String requestId = UUID.randomUUID().toString();
//        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
//        if (urlParameters != null) {
//            Map<String, String> map = new HashMap();
//            urlParameters.stream().forEach(nameVal -> {
//                map.put(nameVal.getName(), nameVal.getValue());
//                builder.queryParam(nameVal.getName(), nameVal.getValue());
//            });
//        }
//
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders requestHeaders = new HttpHeaders();
//        String host = hostUrl.replace("http://", "").replace("https://", "");
//        byte[] digest = MessageDigest.getInstance("SHA-256").digest("".getBytes());
//        try {
//            requestHeaders.add("host", host);
//            requestHeaders.add("original-date", nowDate);
//            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digest)));
//            requestHeaders.add("x-request-id", requestId);
//            URL url = new URL(builder.toUriString());
//
//            requestHeaders.add("authorization", sigServ.generateSignature(host, "GET", url.getPath()+"?"+url.getQuery(), null, "application/x-www-form-urlencoded", requestId));
//        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
//            LOG.error("could not generate signature!!");
//            LOG.error(e.getMessage());
//        }
//
//        HttpEntity entity = new HttpEntity(requestHeaders);
//        ResponseEntity<String> response = restTemplate.exchange(
//                builder.toUriString(), HttpMethod.GET, entity, String.class);
//        return response.getBody();
//    }
//
//    public SessionMngrResponse sendGetSMResponse(String hostUrl, String uri,
//            List<NameValuePair> urlParameters) throws IOException, NoSuchAlgorithmException {
//
//        Date date = new Date();
//        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z",Locale.ENGLISH);
//        String nowDate = formatter.format(date);
//        String requestId = UUID.randomUUID().toString();
//        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hostUrl + uri);
//        if (urlParameters != null) {
//            Map<String, String> map = new HashMap();
//            urlParameters.stream().forEach(nameVal -> {
//                map.put(nameVal.getName(), nameVal.getValue());
//                builder.queryParam(nameVal.getName(), nameVal.getValue());
//            });
//        }
//
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders requestHeaders = new HttpHeaders();
//        String host = hostUrl.replace("http://", "").replace("https://", "");
//        byte[] digest = MessageDigest.getInstance("SHA-256").digest("".getBytes());
//        try {
//            requestHeaders.add("host", host);
//            requestHeaders.add("original-date", nowDate);
//            requestHeaders.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digest)));
//            requestHeaders.add("x-request-id", requestId);
//            URL url = new URL(builder.toUriString());
//
//            requestHeaders.add("authorization", sigServ.generateSignature(host, "GET", url.getPath()+"?"+url.getQuery(), null, "application/x-www-form-urlencoded", requestId));
//        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
//            LOG.error("could not generate signature!!");
//            LOG.error(e.getMessage());
//        }
//
//        HttpEntity entity = new HttpEntity(requestHeaders);
//        ResponseEntity<SessionMngrResponse> response = restTemplate.exchange(
//                builder.toUriString(), HttpMethod.GET, entity, SessionMngrResponse.class);
//        return response.getBody();
//    }
//    
//    
//
//    private void addHeaders(HttpHeaders headers, String host, Date date, byte[] digestBytes, String uri, String requestId) throws NoSuchAlgorithmException {
//        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM YYYY HH:mm:ss z",Locale.ENGLISH);
//        String nowDate = formatter.format(date);
//        headers.add("host", host);
//        headers.add("original-date", nowDate);
//        headers.add("digest", "SHA-256=" + new String(org.tomitribe.auth.signatures.Base64.encodeBase64(digestBytes)));
//        headers.add("x-request-id", requestId);
//
//    }

}
