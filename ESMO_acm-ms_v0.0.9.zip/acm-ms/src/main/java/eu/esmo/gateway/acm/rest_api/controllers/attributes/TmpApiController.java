package eu.esmo.gateway.acm.rest_api.controllers.attributes;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.util.HashMap;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import eu.esmo.gateway.acm.rest_api.services.attributes.AttributesService;
import eu.esmo.gateway.acm.services.SessionManagerConnService;
import io.swagger.annotations.ApiParam;

@Controller
public class TmpApiController 
{
	@Autowired
	private AttributesService attributesService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	SessionManagerConnService smConnService;//[TODO]Quitar
	
	
	//@GetMapping("/tmp/testOne")
	//@RequestMapping(value = "/tmp/request", method = RequestMethod.GET)
	//@ApiParam(value = "References the session and attribute list(s) in the Session Manager" ,required=true )  @Valid
	@GetMapping("/tmp/request")
	String tmpRequest(String sessionId, Model model) throws Exception
	{
		
		System.out.println("||||||||||| En tmpResquest sessionId:"+sessionId);
		System.out.println("&&&&&&&LEO(tmpRequest) todas las variables de la sessionId:"+sessionId);
		if (sessionId != "")
		{
		HashMap<String, Object> vblesList = smConnService.readVariables(sessionId);
		
		vblesList.forEach((st,obj) -> System.out.println("Variable "+st+":"+obj.toString()) );
		}
		System.out.println("&&&&&&&FIN(tmpRequest) de leer todas las variables de la sessionId:"+sessionId);

		
		
		
		System.out.println("||||||||||| En tmpResquest session.sessionID:"+session.getAttribute("sessionId"));
		 return attributesService.goToMultiUI(sessionId , model);
		//return "";
	}


	
	
	@GetMapping("/tmp/urlReturn")
	String tmpUrlReturn(String sessionId,Model model) throws Exception
	{
		System.out.println("||||||||||| En tmpUrlReturn sessionId:"+sessionId);
		System.out.println("||||||||||| 2.En tmpUrlReturn sessionId:"+session.getAttribute("sessionId"));
		if (sessionId== null)
		{
			sessionId = (String) session.getAttribute("sessionId");
		}
		
		
		
		return attributesService.returnFromMultiUI( sessionId, model); 
	}
	
	
	@GetMapping("/urlFinishProcess")
	String urlFinishProcess(String sessionId,Model model) throws Exception
	{
		if (sessionId== null)
		{
			sessionId = (String) session.getAttribute("sessionId");
		}
		
		return attributesService.finishFromMulti( sessionId, model);
		
	}
}
