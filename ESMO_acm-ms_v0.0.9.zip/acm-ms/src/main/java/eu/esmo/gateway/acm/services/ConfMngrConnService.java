package eu.esmo.gateway.acm.services;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.util.List;

import eu.esmo.gateway.acm.domain.AttributeTypeList;
import eu.esmo.gateway.acm.domain.EntityMetadata;
import eu.esmo.gateway.acm.domain.EntityMetadataList;
import eu.esmo.gateway.acm.domain.MsMetadataList;

public interface ConfMngrConnService 
{
	public List<String> getAttributeProfiles ();
	public AttributeTypeList getAttributeSetByProfile(String profileId,int attempt);
	
	public List<String> getExternalEntities (); // returns available **collections**
	public EntityMetadataList getEntityMetadataSet (String collectionId,int attempt);
	public EntityMetadata getEntityMetadata (String collectionId, String entityId,int attempt);
	
	public MsMetadataList getAllMicroservices ();
	public MsMetadataList getMicroservicesByApiClass (String apiClasses,int attempt); // input like "SP, IDP, AP, GW, ACM, SM, CM"
	EntityMetadata getConfiguration(String confId);
	
}

