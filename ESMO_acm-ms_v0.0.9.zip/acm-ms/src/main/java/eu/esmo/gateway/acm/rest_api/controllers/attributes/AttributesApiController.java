package eu.esmo.gateway.acm.rest_api.controllers.attributes;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import eu.esmo.gateway.acm.rest_api.domain.MsResponse;
import eu.esmo.gateway.acm.rest_api.services.attributes.AttributesService;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-11-29T14:30:50.899Z")

@Controller
public class AttributesApiController implements AttributesApi {

	
	@Autowired
	private AttributesService attributesService;
	
    private static final Logger log = LoggerFactory.getLogger(AttributesApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public AttributesApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

//    public ResponseEntity<MsResponse> requestAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager.",required=true) @PathVariable("msToken") String msToken) {
//    public ResponseEntity<MsResponse> requestAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager" ,required=true )  @Valid @RequestBody String msToken, Model model) {
    public String requestAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager" ,required=true )  @Valid @RequestBody String msToken, Model model) {
    	String accept = request.getHeader("Accept");
        //if (accept != null && accept.contains("application/json")) {
            try {
            	return attributesService.requestAttributes( msToken, model);
                //return new ResponseEntity<MsResponse>(objectMapper.readValue("{  \"code\" : 0,  \"type\" : \"type\",  \"message\" : \"message\"}", MsResponse.class), HttpStatus.NOT_IMPLEMENTED);
            
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                //return new ResponseEntity<MsResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (Exception e) {//para attributesService
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        //}

        //return new ResponseEntity<MsResponse>(HttpStatus.NOT_IMPLEMENTED);
        return "";
    }
    
    public String requestAttributes2(String sessionId, Model model) {
    	
    	log.info("0. En requestAttributes2");
    	//String accept = request.getHeader("Accept");
        //if (accept != null && accept.contains("application/json")) {
            try {
            	
            	String sReturn=  attributesService.requestAttributes2( sessionId, model);
            	log.info("2. En requestAttributes2: "+sReturn);
            	return sReturn;
                //return new ResponseEntity<MsResponse>(objectMapper.readValue("{  \"code\" : 0,  \"type\" : \"type\",  \"message\" : \"message\"}", MsResponse.class), HttpStatus.NOT_IMPLEMENTED);
            
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                //return new ResponseEntity<MsResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (Exception e) {//para attributesService
				// TODO Auto-generated catch block
            	log.error("Exception: "+e.getMessage());
				e.printStackTrace();
			}
        //}

        //return new ResponseEntity<MsResponse>(HttpStatus.NOT_IMPLEMENTED);
        return "";
    }
    

    //public ResponseEntity<MsResponse> responseAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager.",required=true) @PathVariable("msToken") String msToken) {
    public String responseAttributes(@ApiParam(value = "References the session and attribute list(s) in the Session Manager." ,required=true )  @Valid @RequestBody String msToken, Model model) {
        String accept = request.getHeader("Accept");
        //if (accept != null && accept.contains("application/json")) {
            try {
            	
            	String sReturn = attributesService.responseAttributes(msToken, model);
            	return sReturn;
            	//new ResponseEntity<MsResponse>(objectMapper.readValue("{  \"code\" : 0,  \"type\" : \"type\",  \"message\" : \"message\"}", MsResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return "HttpStatus.INTERNAL_SERVER_ERROR";
                //return new ResponseEntity<MsResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (Exception e) {//para attributesService.responseAttributes
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        //}

        //return new ResponseEntity<MsResponse>(HttpStatus.NOT_IMPLEMENTED);
        MsResponse msResponse = new MsResponse();
		msResponse.setCode(0);
		msResponse.setMessage("Hello World ACM RESPONSE");
		msResponse.setType("OK");
		
		return "ERROR";//new ResponseEntity<MsResponse>(msResponse,HttpStatus.OK);
    }

	@Override
	public ResponseEntity<MsResponse> helloWord() {
//		// TODO Auto-generated method stub
//		return null;
		MsResponse msResponse = new MsResponse();
		msResponse.setCode(0);
		msResponse.setMessage("Hello World");
		msResponse.setType("OK");
		
		return new ResponseEntity<MsResponse>(msResponse,HttpStatus.OK);
	}

	@Override
	public String requestAttributes3(String token)
	{
		String sReturn="ERROR";
		
		try 
		{
			sReturn = attributesService.responseAttributes3(token);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return sReturn;
	}

	@Override
	public String requestAllVbles(String sessionId) 
	{
		String sReturn="ERROR";
		
		try {
			sReturn = attributesService.readAllVariables(sessionId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return sReturn;
	}
	
//	@Override
//	public String requestAttributes3(String token)
//	{
//		
//		String sReturn="ERROR";
//		try 
//		{
//			sReturn = attributesService.responseAttributes3(token);
//		} 
//		catch (Exception e) 
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
//		return sReturn;
//	}
//
//	
//	@Override
//	public String requestAllVbles(String sessionId) 
//	{
//		// TODO Auto-generated method stub
//		return null;
//	}


//	@Override
//	public String requestAttributes3(String msToken, Model model) {
//		
//		
//		
//		String sReturn="ERROR";
//		try {
//			sReturn = attributesService.responseAttributes3(msToken, model);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    	return sReturn;
//	}
	
}




//@Controller
//public class SpApiController implements SpApi {
//
//    private static final Logger log = LoggerFactory.getLogger(SpApiController.class);
//
//    private final ObjectMapper objectMapper;
//
//    private final HttpServletRequest request;
//
//    @org.springframework.beans.factory.annotation.Autowired
//    public SpApiController(ObjectMapper objectMapper, HttpServletRequest request) {
//        this.objectMapper = objectMapper;
//        this.request = request;
//    }
//
//    public ResponseEntity<Void> spResponsePost(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken,@ApiParam(value = "The standard response object(s) representing the response(s) the remote IdP and/or AP(s) issued" ,required=true) @RequestHeader(value="responseAssertions", required=true) ERRORUNKNOWN responseAssertions) {
//        String accept = request.getHeader("Accept");
//        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
//    }
//
//}

