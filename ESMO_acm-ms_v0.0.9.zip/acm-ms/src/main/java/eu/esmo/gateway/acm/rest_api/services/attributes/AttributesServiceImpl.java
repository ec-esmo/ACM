package eu.esmo.gateway.acm.rest_api.services.attributes;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.io.IOException;
import java.util.HashMap;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.acm.domain.ApiCallType;
import eu.esmo.gateway.acm.domain.ApiClassEnum;
import eu.esmo.gateway.acm.domain.AttributeSet;
import eu.esmo.gateway.acm.domain.AttributeSetList;
import eu.esmo.gateway.acm.domain.AttributeSetStatus;
import eu.esmo.gateway.acm.domain.AttributeType;
import eu.esmo.gateway.acm.domain.AttributeTypeList;
import eu.esmo.gateway.acm.domain.EndpointType;
import eu.esmo.gateway.acm.domain.EntityMetadata;
import eu.esmo.gateway.acm.domain.EntityMetadataList;
import eu.esmo.gateway.acm.domain.MsMetadata;
import eu.esmo.gateway.acm.domain.MsMetadataList;
import eu.esmo.gateway.acm.domain.PublishedApiType;
import eu.esmo.gateway.acm.domain.AttributeSet.TypeEnum;
import eu.esmo.gateway.acm.services.ConfMngrConnService;
import eu.esmo.gateway.acm.services.ParameterService;
import eu.esmo.gateway.acm.services.SessionManagerConnService;

@Service
public class AttributesServiceImpl implements AttributesService
{
	private static final Logger log = LoggerFactory.getLogger(AttributesServiceImpl.class);
	
	@Autowired
	HttpSession session;
	
	@Autowired
	SessionManagerConnService smConnService;
	
	@Autowired
	ConfMngrConnService cmConnService;
	
	AttributeTypeList attTypeListEIDAS = null;
	EntityMetadataList entityListIDP = null;
	EntityMetadataList entityListAP = null;
	EntityMetadataList entityListRAP = null;
	EntityMetadataList entityListRGW = null;
	
	
	MsMetadataList idpMetadataList = null;
	MsMetadataList spMetadataList = null;
	MsMetadataList apMetadataList = null;
	MsMetadataList gwMetadataList = null;

//	@Autowired
//	ParameterService paramServ;
//	//ACM_MS_NAME
	
	private String acmMsName;
	
	@Autowired
	public AttributesServiceImpl(ParameterService paramServ)
	{
		acmMsName = paramServ.getParam("ACM_MS_NAME");
		if (acmMsName==null || acmMsName=="")
		{
			acmMsName = "ACMms001";
		}
	}
	
	
	@Override
	public String requestAttributes(String msToken, Model model) throws Exception 
	{
		
		
		// Revisar token recibido
		//				 
		if (msToken.endsWith("="))
		{
			msToken = msToken.replace("=", "");
		}
		if (msToken.startsWith("msToken="))
		{
			msToken = msToken.replace("msToken=", "");
		}
		log.info("***after:<"+msToken+">");
		
		// Antes de empezar compruebo que tengo los datos del CM rellenos si no es así lo relleno
		fillCMData();
		
		
		// ReqAtt01. Llamar al servicio de SessionManager(SM) /validateToken con el msToken
		// 		     Obtener de SessionManagerResponse el sessionId -> se hace en SessionManagerConnService
		String sessionId="";
		try
		{
			sessionId = smConnService.validateToken( msToken);
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (validateToken) with token:"+msToken+"\n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        return "acmError";
		}
		if (sessionId == "")
		{
			String errorMsg= "Error response from SM (validateToken) with token:"+msToken+"\n";
			errorMsg += smConnService.getLastSMResponse();
			model.addAttribute("ErrorMessage",errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	       
	        return "acmError";
		}
		log.info("RequestAttributes: Token validated sessionId:"+sessionId);
		log.info(readAllVariables(sessionId));
		
		
		
		// ReqAtt02. Llamar al servicio de SessionManager /getSessionData con el sessionId 
		//			  y variableName="spRequest" (que es de tipo attributeSet (REQUEST))
		//  		 Obtener de SessionManagerResponse la variable spRequest 
		
		//AttributeSet spRequest = readSpRequest(model, sessionId); //falta la parte de error
		Object objSpRequest = null;
		AttributeSet spRequest = null;
		try
		{
			objSpRequest = smConnService.readVariable(sessionId, "spRequest");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        return "acmError";
			
		}
		spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
		log.info("RequestAttributes: Reading spRequest");
		//System.out.println("spRequest:"+spRequest.toString() );
		
		// ReqAtt03. Llamar al servicio de SessionManager /getSessionData con el sessionId 
		//			  y variableName="spMetadata" (que es de tipo EntityMetadata)
		//  		 Obtener de SessionManagerResponse la variable spMetadata 
		
		//EntityMetadata spMetadata = readSpMetadata(model, sessionId);
		EntityMetadata spMetadata = null;
		Object objSpMetadata = null;
		try
		{
			objSpMetadata = smConnService.readVariable(sessionId, "spMetadata");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        //return "acmError";
		}
		spMetadata = (new ObjectMapper()).readValue(objSpMetadata.toString(),EntityMetadata.class);
		log.info("RequestAttributes: Reading spMetadata");
		//System.out.println("spMetadata:"+spMetadata.toString());
		
		//
		// ReqAtt04. Miro si esta en el SM la variable "authenticationSet" (AttributeSet)
		//
		AttributeSet authenticationSet = null;
		Object objAuthSet = null;
		try
		{
			objAuthSet = smConnService.readVariable(sessionId, "authenticationSet");
		}
		catch (Exception ex)
		{
			log.info("RequestAttributes: Excepcion al leer authenticationSet");
			System.out.println("RequestAttributes: Excepcion al leer authenticationSet "+ex.getMessage());
		}
		if (objAuthSet!= null)
		{
			authenticationSet = (new ObjectMapper()).readValue(objAuthSet.toString(),AttributeSet.class);
		}
		
		//
		// ReqAtt05. Miro si esta en el SM la variable "apEntityId"
		//
		String apEntityId = null;
		try
		{
			apEntityId = (String) smConnService.readVariable(sessionId, "apEntityId");
			log.info("Leida apEntityID="+apEntityId);
			apEntityId = apEntityId.replaceAll("\"", "");
			log.info("Leida apEntityID="+apEntityId);
		}
		catch (Exception ex)
		{
			log.info("RequestAttributes: Excepcion al leer apEntityId");
			System.out.println("RequestAttributes: Excepcion al leer apEntityId "+ex.getMessage());
		}
		
		if (apEntityId!=null && apEntityId!="")
		{	
			log.info("RequestAttributes: apEntityId isnt null -> I go to prepareAndGotoAPms");
			//CASO C
			EntityMetadata apMetadata = getAPMetadata(apEntityId);
			if (apMetadata != null)
			{
				return prepareAndGotoAPms(sessionId, model, spRequest, spMetadata, apMetadata, authenticationSet);
			}
		}
		log.info("RequestAttributes: apEntityId is NULL");
		
		//  NO TENEMOS apEntityId
		
		// ReqAtt06. Busco en la lista de atributos de spRequest si se piden attributos de Eidas
		AttributeSet idpRequest = new AttributeSet();
		
//		for ( AttributeType attributeRequested : spRequest.getAttributes())
//		{
//			String friendlyName = attributeRequested.getFriendlyName();
//			System.out.println("### BUSCANDO:"+friendlyName);
//			Optional<AttributeType> foundAtt = attTypeListEIDAS.stream().filter(a ->a.getFriendlyName().equals(friendlyName) ).findAny();
//			if (foundAtt.isPresent())
//			{
//				idpRequest.addAttributesItem( foundAtt.get());
//				System.out.println("FoundAtt:"+foundAtt.get());
//				System.out.println("RequestAtt:"+attributeRequested);
//			}
//			
//		}
		for ( AttributeType attributeRequested : spRequest.getAttributes())
		{
			
			Optional<AttributeType> foundAtt=null;
			String friendlyName = attributeRequested.getFriendlyName();
			String name = attributeRequested.getName();
			System.out.println("### BUSCANDO att friendlyName:"+friendlyName);
			System.out.println("### BUSCANDO att name:"+name);
			if (friendlyName != null)
			{	
				foundAtt = attTypeListEIDAS.stream().filter(a ->a.getFriendlyName().equals(friendlyName) ).findAny();
			}
			else if (name !=null)
			{
				foundAtt = attTypeListEIDAS.stream().filter(a ->a.getName().equals(name) ).findAny();
			}
						
			if (foundAtt !=null && foundAtt.isPresent())
			{
				idpRequest.addAttributesItem( foundAtt.get());
				System.out.println("FoundAtt:"+foundAtt.get());
				System.out.println("RequestAtt:"+attributeRequested);
			}
			else
			{
				System.out.println("### NOT found");
			}
		}
		
		if (authenticationSet != null)
		{
			log.info("RequestAttributes: authenticationSet isnt null -> prepareAndGotoMultiUI");
			
			return prepareAndGotoMultiUI(sessionId, model, spRequest, authenticationSet, null ,null); // responseAssertions, errorMsg);
		}
		log.info("RequestAttributes: authenticationSet is NULL");
		
		if (idpRequest.getAttributes()!=null && idpRequest.getAttributes().size()>0)
		{
			//CASO A Se piden atributos de EIDAS y redirecciono al IDP
			log.info("RequestAttributes: I go to prepareAndGotoIDPms");
			return prepareAndGotoIDPms( sessionId, model, spRequest, idpRequest);
		}
		else
		{
			String errorMsg= "ACM hasnt found in request attributes to request to the idp  \n";
			errorMsg += "spRequest: "+spRequest.toString();
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
			
		}
		
		return "acmError";
	}


	//privacyPolicy: ${URL_PRIVACY_POLICY}
	//  consentQuery: ${TEXT_CONSENT_QUERY}
	//  consentFinish: ${TEXT_CONSENT_FINISH}
	@Value("${multiui.privacyPolicy}") //Defined in application.properties file
    String privacyPolicy;
	
	@Value("${multiui.consentQuery}") //Defined in application.properties file
    String consentQuery;
	
	@Value("${multiui.consentFinish}") //Defined in application.properties file
    String consentFinish;

	private String prepareAndGotoMultiUI( String sessionId, Model model, 
									      AttributeSet spRequest, AttributeSet authenticationSet, 
									      AttributeSetList responseAssertions,
									      String errorMessage) 
	
	{
		//Rellenar apsList
		EntityMetadataList apsList = new EntityMetadataList();
		
		if (entityListAP != null && entityListAP.size()>0)
		{
			log.info("Readed AP adding");
			apsList.addAll(entityListAP);
		}
		if (entityListRAP != null && entityListRAP.size()>0)
		{   
			log.info("Readed RemoteAP adding");
			apsList.addAll(entityListRAP);
		}
		if (entityListRGW != null && entityListRGW.size()>0)
		{
			log.info("Readed RemoteGW adding");
			apsList.addAll(entityListRGW);
		}
		
		//Rellenar attributesRequesList y //Rellenar attributesSendList
		AttributeTypeList attributesRequestList = new AttributeTypeList();
		AttributeTypeList attributesSendList = new AttributeTypeList(); 
		for ( AttributeType attributeRequested : spRequest.getAttributes())
		{
			//attributeRequest
			String friendlyName = attributeRequested.getFriendlyName();
			Optional<AttributeType> foundAtt = attTypeListEIDAS.stream().filter(a ->a.getFriendlyName().equals(friendlyName) ).findAny();

			if (!foundAtt.isPresent()) //No es Eidas
			{
				attributesRequestList.add(attributeRequested);
			}
			else
			{
				attributesSendList.add(attributeRequested);//¿Este no lo tengo ya?
			}
		}
		if ( authenticationSet!= null && authenticationSet.getAttributes().size() > 0)
		{
			attributesSendList.clear();
			for ( AttributeType att : authenticationSet.getAttributes())
			{
				attributesSendList.add( att);
			}
			//attributesSendList = (AttributeTypeList) authenticationSet.getAttributes();//da excepcion
//			for (int i=0; i< authenticationSet.getAttributes().size();i++)
//			{
//				attributesSendList.add( authenticationSet.getAttributes().get(i));
//			}
		}
		
		String urlReturn= "tmp/urlReturn"; //[TODO] Revisar
		String urlFinishProcess = "urlFinishProcess";
		session.setAttribute("apsList", apsList);  //?? Es session o model
		session.setAttribute("attributesRequestList", attributesRequestList);
		session.setAttribute("attributesSendList", attributesSendList);
		session.setAttribute("attributesConsentList", responseAssertions);
		session.setAttribute("urlReturn", urlReturn);
		session.setAttribute("urlFinishProcess", urlFinishProcess);
		session.setAttribute("sessionId", sessionId);
		if(errorMessage != null)
		{
			session.setAttribute("errorMessage", errorMessage);
		}
		//String errorMessage = (String) session.getAttribute("errorMessage");
		if (privacyPolicy != null)
		{
			session.setAttribute("privacyPolicy",privacyPolicy);
		}
		if (consentQuery != null)
		{
			session.setAttribute("consentQuery",consentQuery);
		}
		if (consentFinish != null)
		{
			session.setAttribute("consentFinish",consentFinish);
		}
		
		
		model.addAttribute("apsList", apsList);
		model.addAttribute("attributesRequestList", attributesRequestList);
		model.addAttribute("attributesSendList", attributesSendList);
	
		log.info("Redireccion a MultiUI ( /acm/client)");
		//redireccionar a multiUI
		//return "client";
		return "redirect:../acm/client";//return "acmError";
	}
	
	@Override
	public String returnFromMultiUI(String sessionId, Model model) throws Exception 
	{
		EntityMetadataList apsList = (EntityMetadataList) session.getAttribute("apsList");
		//System.out.println("Recibido desde MultiUI: apsList:"+apsList);
		AttributeTypeList attributesRequestList = (AttributeTypeList) session.getAttribute("attributesRequestList");// other attributes
		//System.out.println("Recibido desde MultiUI: attributesRequestList:"+attributesRequestList);
		AttributeTypeList attributesSendList = (AttributeTypeList) session.getAttribute("attributesSendList");  //authentication
		//System.out.println("Recibido desde MultiUI: attributesSendList:"+attributesSendList);
		
		/// spRequest y spMetadata podrian estar guardados en el ACMState para multiui
		///
		Object objSpRequest = null;
		AttributeSet spRequest = null;
		try
		{
			objSpRequest = smConnService.readVariable(sessionId, "spRequest");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        return "acmError";
			
		}
		spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
		log.info("returnFromMultiUI: Reading spRequest");
		//System.out.println("spRequest:"+spRequest.toString() );
		
		// read spMetadata 
		EntityMetadata spMetadata = null;
		Object objSpMetadata = null;
		try
		{
			objSpMetadata = smConnService.readVariable(sessionId, "spMetadata");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        //return "acmError";
		}
		spMetadata = (new ObjectMapper()).readValue(objSpMetadata.toString(),EntityMetadata.class);
		log.info("returnFromMultiUI: Reading spMetadata");
		///
		///
		
		AttributeSet dsaRequest = new AttributeSet();
		dsaRequest.setAttributes( attributesRequestList);
		dsaRequest.setIssuer( spRequest.getIssuer());
		dsaRequest.setProperties( spRequest.getProperties());
		
		AttributeSet autSet =  new AttributeSet();
		autSet.setAttributes( attributesSendList);
		
		
		return prepareAndGotoAPmsFromMultiUI( sessionId, model, dsaRequest, spMetadata, apsList.get(0), autSet );
		
		//return "acmError";
	}
	
	// Caso en el que exista apEntityId
	private String prepareAndGotoAPmsFromMultiUI(String sessionId, Model model, 
									  AttributeSet spRequest, EntityMetadata spMetadata, 
									  EntityMetadata apMetadata, AttributeSet authenticationSet) throws Exception
	{
//		EntityMetadata apMetadata = null;
//		for ( int i=0; i<entityListAP.size(); i++)
//		{
//			EntityMetadata currentAPMetadata = entityListAP.get(i);
//			if (currentAPMetadata.getEntityId().equalsIgnoreCase(apEntityId))
//			{
//				apMetadata = currentAPMetadata;
//				break;
//			}
//	
		log.info("In prepareAndGotoAPmsFromMultiUI");
		log.info("In prepareAndGotoAPmsFromMultiUI apMetadata:"+apMetadata);
		
		///  Añado/actualizo authenticationSet al SM
		///
		ObjectMapper objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"authenticationSet",objMapper.writeValueAsString(authenticationSet));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable authenticationSet)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		///		Añado apMetadata al SM
		/// 
		objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"apMetadata",objMapper.writeValueAsString(apMetadata));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable apMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		///		Creo apRequest
		///
		AttributeSet apRequest = new AttributeSet();
		apRequest.setId( UUID.randomUUID().toString());
		apRequest.setType(AttributeSet.TypeEnum.REQUEST);
		apRequest.setIssuer( spRequest.getIssuer());
		apRequest.setRecipient( apMetadata.getEntityId());//[TODO] Review
		apRequest.setProperties( spRequest.getProperties());
		
		apRequest.setAttributes(spRequest.getAttributes()); /// En este caso se copian tal cual
		
		///		Añado apRequest al SM
		//
		objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"apRequest",objMapper.writeValueAsString(apRequest));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable apRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
//		if ( entityListRAP.contains(apMetadata))
//		{
//			objMapper = new ObjectMapper();
//			try
//			{
//				smConnService.,objMapper.writeValueAsString(apMetadata.getEntityId()));
//				System.out.println("#####################Relleno updateVariable(sessionId,"apEntityId"apEntityId"+apMetadata.getEntityId());	
//			}
//			catch (Exception ex)
//			{
//				String errorMsg= "Exception calling SM (updateVariable apRequest)  \n";
//				errorMsg += "Exception message:"+ex.getMessage()+"\n";
//				model.addAttribute("ErrorMessage",errorMsg);
//				log.error(errorMsg);
//		        return "acmError";
//			}
//		}
//		else
//		{
//			objMapper = new ObjectMapper();
//			try
//			{
//				smConnService.updateVariable(sessionId,"apEntityId",null);
//			}
//			catch (Exception ex)
//			{}
//		}


		
		//  Busco el endpoint para la redireccion
		//
		String msName = apMetadata.getMicroservice().get(0);
		MsMetadata microservice = null;
		for (int i =0; i<apMetadataList.size(); i++)
		{
			MsMetadata iMs = apMetadataList.get(i);
			if ( iMs.getMsId().equalsIgnoreCase(msName))
			{
				microservice = iMs;
				log.info("En prepareAndGotoAPmsFromMultiUI microservice:"+microservice.toString());
				break;
			}
		}
		if (microservice==null)
		{
			String errorMsg= "Error getting microservice "+msName+" \n";
			
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		//microservice.getPublishedAPI().get(0).getApiClass()
		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
											.filter(a->((a.getApiClass()==ApiClassEnum.AP)||(a.getApiClass()==ApiClassEnum.GW)) && a.getApiCall()==ApiCallType.query ).findAny();
		String endPoint = null;
		if (optPubApi.isPresent())
		{
			PublishedApiType pubApi = optPubApi.get();
			endPoint = pubApi.getApiEndpoint();
			log.info("En prepareAndGotoAPmsFromMultiUI pubApi:"+pubApi.toString());
			
		}
		
		//  Generar un msToken para enviar a APms con /generateToken a SM
		String tokenToAPms = smConnService.generateToken(sessionId,acmMsName, msName); //[TODO] Poner try/catch¿?
		System.out.println("tokenToAPms:"+tokenToAPms);
				
		//String url = "https://stork.uji.es/clave1b/module.php/esmo/ap/query.php/saml2";//el de Paco
		String url = endPoint;
		model.addAttribute("msToken", tokenToAPms);
		model.addAttribute("UrlToRedirect", url);
		System.out.println("En prepareAndGotoAPmsFromMultiUI -> Devuelvo idpRedirect "+url);
		       
		return "idpRedirect";
	}

	


	private String prepareAndGotoIDPms( String sessionId, Model model, 
									  AttributeSet spRequest, AttributeSet idpRequest) throws Exception
	{
		//[TODO] DE momento cojo el primer, luego aleatorio?
		EntityMetadata idpMetadata = entityListIDP.get(0);
		
		///		Añado idpMetadata al SM
		///
		ObjectMapper objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"idpMetadata",objMapper.writeValueAsString(idpMetadata));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable idpMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		//	Completo la idpRequest
		//  los atributos deberían estar la rellenos antes de llamar a este metodo
		idpRequest.setId( UUID.randomUUID().toString());
		idpRequest.setType(AttributeSet.TypeEnum.REQUEST);
		idpRequest.setIssuer( spRequest.getIssuer());
		idpRequest.setRecipient( idpMetadata.getEntityId());
		idpRequest.setProperties( spRequest.getProperties());
		idpRequest.setLoa( spRequest.getLoa());
		
		
		///		Añado idpRequest al SM
		///
		objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"idpRequest",objMapper.writeValueAsString(idpRequest));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable idpRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		//  Busco el endpoint para la redireccion
		//
		String msName = idpMetadata.getMicroservice().get(0);
		if (msName.equalsIgnoreCase("SAMLms001"))   //TODO:Quitar
		{
			msName="SAMLms_0001";
		}
		//msName = "SAMLms001";  //
		MsMetadata microservice = null;
		
		for (int i =0; i<idpMetadataList.size(); i++)
		{
			MsMetadata iMs = idpMetadataList.get(i);
			if ( iMs.getMsId().equalsIgnoreCase(msName))
			{
				microservice = iMs;
				break;
			}
		}
		if (microservice==null)
		{
			String errorMsg= "Error getting microservice "+msName+" \n";
			
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		//microservice.getPublishedAPI().get(0).getApiClass()
		String endPoint = null;
		if (microservice != null)
		{
			Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream() 
												.filter(a->(a.getApiClass()==ApiClassEnum.IDP && a.getApiCall()==ApiCallType.authenticate) ).findAny();
			
			if (optPubApi.isPresent())
			{
				PublishedApiType pubApi = optPubApi.get();
				endPoint = pubApi.getApiEndpoint();
				log.info("En prepareAndGotoIDPms pubApi:"+pubApi.toString());
			}
		}
			
		//  Generar un msToken para enviar a IDPms con /generateToken a SM
		String tokenToIDPms = smConnService.generateToken(sessionId,acmMsName,msName);
		System.out.println("tokenToIDPms:"+tokenToIDPms);
		
		String url = endPoint;
		//url = "http://165.227.151.145:8091/idp/authenticate"; //Mockup de Nikos
		model.addAttribute("msToken", tokenToIDPms);
		model.addAttribute("UrlToRedirect", url);
		System.out.println("En prepareAndGotoIDPms -> Devuelvo idpRedirect "+url);
		       
		return "idpRedirect";
	}

	
	private String prepareAndGotoAPms(String sessionId, Model model, 
									  AttributeSet spRequest, EntityMetadata spMetadata, 
									  EntityMetadata apMetadata, AttributeSet authenticationSet) throws Exception
	{
		///		Añado authenticationSet al SM
		///
		///		No hace falta porque ya esta en el SM
//		ObjectMapper objMapper = new ObjectMapper();
//		try
//		{
//			smConnService.updateVariable(sessionId,"authenticationSet",objMapper.writeValueAsString(authenticationSet));
//		}
//		catch (Exception ex)
//		{
//			String errorMsg= "Exception calling SM (updateVariable authenticationSet)  \n";
//			errorMsg += "Exception message:"+ex.getMessage()+"\n";
//			model.addAttribute("ErrorMessage",errorMsg);
//			log.error(errorMsg);
//	        return "acmError";
//		}
		
		///		Añado apMetadata al SM
		///
		ObjectMapper objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"apMetadata",objMapper.writeValueAsString(apMetadata));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable apMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		///		Creo apRequest
		///
		AttributeSet apRequest = new AttributeSet();
		apRequest.setId( UUID.randomUUID().toString());
		apRequest.setType(AttributeSet.TypeEnum.REQUEST);
		apRequest.setIssuer( spRequest.getIssuer());
		apRequest.setRecipient( apMetadata.getEntityId());
		apRequest.setProperties( spRequest.getProperties());
		
		apRequest.setAttributes( spRequest.getAttributes()); /// En este caso se copian tal cual
		
		///		Añado apRequest al SM
		//
		objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"apRequest",objMapper.writeValueAsString(apRequest));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable apRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}

//		if ( entityListRAP.contains(apMetadata))
//		{
//			objMapper = new ObjectMapper();
//			try
//			{
//				smConnService.updateVariable(sessionId,"apEntityId",objMapper.writeValueAsString(apMetadata.getEntityId()));
//			}
//			catch (Exception ex)
//			{
//				String errorMsg= "Exception calling SM (updateVariable apRequest)  \n";
//				errorMsg += "Exception message:"+ex.getMessage()+"\n";
//				model.addAttribute("ErrorMessage",errorMsg);
//				log.error(errorMsg);
//		        return "acmError";
//			}
//		}

		
		//  Busco el endpoint para la redireccion
		//
		String msName = apMetadata.getMicroservice().get(0);
		MsMetadata microservice = null;
		for (int i =0; i<apMetadataList.size(); i++)
		{
			MsMetadata iMs = apMetadataList.get(i);
			if ( iMs.getMsId().equalsIgnoreCase(msName))
			{
				microservice = iMs;
				break;
			}
		}
		if (microservice==null)
		{
			String errorMsg= "Error getting microservice "+msName+" \n";
			
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		//microservice.getPublishedAPI().get(0).getApiClass()
//		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
//											.filter(a->a.getApiClass()==ApiClassEnum.AP ).findAny();
//		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
//				.filter(a->((a.getApiClass()==ApiClassEnum.AP)||(a.getApiClass()==ApiClassEnum.GW)) ).findAny();
		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
				.filter(a->(((a.getApiClass()==ApiClassEnum.AP)||(a.getApiClass()==ApiClassEnum.GW)) && a.getApiCall()==ApiCallType.query) ).findAny();

		
		String endPoint = null;
		if (optPubApi.isPresent())
		{
			PublishedApiType pubApi = optPubApi.get();
			endPoint = pubApi.getApiEndpoint();
			log.info("En prepareAndGotoAPms pubApi:"+pubApi.toString());
		}
		
		//  Generar un msToken para enviar a APms con /generateToken a SM
		String tokenToAPms = smConnService.generateToken(sessionId,acmMsName, msName); //[TODO] Poner try/catch¿?
		System.out.println("tokenToAPms:"+tokenToAPms);
				
		//String url = "https://stork.uji.es/clave1b/module.php/esmo/ap/query.php/saml2";//el de Paco
		String url = endPoint;
		model.addAttribute("msToken", tokenToAPms);
		model.addAttribute("UrlToRedirect", url);
		System.out.println("En prepareAndGotoAPms -> Devuelvo idpRedirect "+url);
		       
		return "idpRedirect";
	}


	private EntityMetadata getAPMetadata(String apEntityId) {
		EntityMetadata apMetadata = null;
		for ( int i=0; i<entityListAP.size(); i++)
		{
			EntityMetadata currentAPMetadata = entityListAP.get(i);
			log.info("Comparo "+currentAPMetadata.getEntityId());
			log.info("Con     "+apEntityId);
			if (currentAPMetadata.getEntityId().equalsIgnoreCase(apEntityId))
			{
				apMetadata = currentAPMetadata;
				break;
			}
		}
		return apMetadata;
	}

	
	/**
	 * Find url to redirect
	 */
//	String urlToRedirect="";
//	if(spMetadataList != null)
//	{
//		try
//		{
//			final String spMicroservice = spMetadata.getMicroservice().get(0);
//			System.out.println("Microservice :"+spMicroservice);
//			//spMicroservice = spMicroservice.replaceAll("\"", "");
//			System.out.println("2. Microservice :"+spMicroservice);
//			Optional<MsMetadata> foundMetadata =  spMetadataList.stream().filter(sp->sp.getMsId().equalsIgnoreCase(spMicroservice)).findAny();
//			if (foundMetadata.isPresent())
//			{
//				//foundMetadata.get().getPublishedAPI()
//				for( PublishedApiType published :  foundMetadata.get().getPublishedAPI())
//				{
//					if (published.getApiClass()==ApiClassEnum.SP)
//					{
//						urlToRedirect = published.getApiEndpoint();
//						System.out.println("urlToRedirect: "+urlToRedirect);
//						break;
//					}
//				}
//			}
//			else throw new Exception("SPms not found in microservices list");
//		
//		}
//		catch (Exception ex)
//		{
//			String errorMsg= "SP microservice to return can't be found  \n";
//			//errorMsg += "Exception message:"+ex.getMessage()+"\n";
//			model.addAttribute("ErrorMessage",errorMsg);
//			log.error(errorMsg);
//	        return "acmError";
//		}
//	}


	@Override
	public String responseAttributes(String msToken, Model model) throws Exception {
		log.info("Starting responseAttributes");
		log.info("***received token:<"+msToken+">");
		fillCMData();
		
		// RespAtt01.  Revisar token recibido
		//				 
		if (msToken.endsWith("="))
		{
			msToken = msToken.replace("=", "");
		}
		if (msToken.startsWith("msToken="))
		{
			msToken = msToken.replace("msToken=", "");
		}
		log.info("***after:<"+msToken+">");

		if (msToken.startsWith("gen"))
		{
			String ss= "f840c49e-b233-496c-8b4a-e11fc72126a4";
			msToken = smConnService.generateToken(ss, "ACMmsOO1", acmMsName);
		}
		
		
		// RespAtt01.  Validar token y obtener sessionId
		//
		String sessionId ="";
		try
		{
			sessionId = smConnService.validateToken(msToken);
		}
		catch (Exception ex)
		{
			String errorMsg= "responseAttributes: Exception calling SM (validateToken) with token:"+msToken+"\n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		if (sessionId == "")
		{
			String errorMsg= "responseAttributes: Error response from SM (validateToken) with token:"+msToken+"\n";
			errorMsg += smConnService.getLastSMResponse();
			model.addAttribute("ErrorMessage",errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	       
	        return "acmError";
		}
		System.out.println("## responseAttributes: sessionId"+sessionId);
		log.info(readAllVariables(sessionId));
		
		
		// RespAtt03.  Llamar al servicio de SessionManager /getSessionData con el sessionId
		//				 y variableName="dsResponse" (que es de tipo attributeSet (RESPONSE))
		Object obj = null;
		try
		{
			 obj = smConnService.readVariable(sessionId, "dsResponse");
		}
		catch (Exception ex)
		{
			String errorMsg= "responseAttributes: Exception calling SM (readVariable dsResponse)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
		AttributeSet dsResponse = (new ObjectMapper()).readValue(obj.toString(),AttributeSet.class);
		log.info("responseAttributes: Reading dsResponse");
		System.out.println("## responseAttributes: dsResponse:"+dsResponse.toString() );
		
//		if (dsResponse.getStatus().getCode() == AttributeSetStatus.CodeEnum.ERROR)	// [TODO] Error especial revisar
//		{
//			String errorMsg= "dsResponse with error  \n";
//			//errorMsg += "Exception message:"+ex.getMessage()+"\n";
//			errorMsg += dsResponse.getStatus().getMessage();
//			model.addAttribute("ErrorMessage",errorMsg);
//			log.error(errorMsg);
//	        return "acmError";
//		}
		//Lo copio despues de leer dsMetadata
		
		// RespAtt04.  Llamar al servicio de SessionManager /getSessionData con el sessionId
		//				 y variableName="dsMetadata" (que es de tipo EntityMetadata)
		EntityMetadata dsMetadata = null;
		Object objDsMetadata = null;
		try
		{
			objDsMetadata = smConnService.readVariable(sessionId, "dsMetadata");
		}
		catch (Exception ex)
		{
			String errorMsg= "responseAttributes: Exception calling SM (readVariable dsMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		log.info("responseAttributes: Reading dsMetadata");
		//System.out.println("dsMetadata:"+objDsMetadata);
		dsMetadata = (new ObjectMapper()).readValue(objDsMetadata.toString(),EntityMetadata.class);
		log.info("responseAttributes: Reading dsMetadata");
		System.out.println("## responseAttributes: dsMetadata:"+dsMetadata.toString() );
		
		if (dsResponse.getStatus().getCode() == AttributeSetStatus.CodeEnum.ERROR)	// [TODO] Error especial revisar
		{	
			if (dsResponse.getType() == TypeEnum.RESPONSE )
				return manageErrorInResponse(sessionId, dsResponse, dsMetadata, model);
			else //TypeEnum.AUTHRESPONSE
			{
				return manageIdpError(sessionId, dsResponse, dsMetadata, model);
			}
		}

		
		
		// RespAtt05.  Miro el tipo de respuesta recibida
		//				 
		TypeEnum responseType = dsResponse.getType();
		if ( responseType == TypeEnum.AUTHRESPONSE ) //Respuesta del IDP
		{
			return manageIdpResponse(sessionId, dsResponse, dsMetadata, model);
		}
		else if (responseType == TypeEnum.RESPONSE)
		{
			return manageAPResponse(sessionId, dsResponse, dsMetadata, model);
		}
		else		// ERROR
		{}
		
		return "acmError";
	}

	
	
//	private String manageIdpError(String sessionId, AttributeSet dsResponse, EntityMetadata dsMetadata, Model model) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	private String manageIdpError(String sessionId, AttributeSet dsResponse, EntityMetadata dsMetadata, Model model) throws JsonParseException, JsonMappingException, IOException 
	{	
		//probar y si hace falta añadir
		AttributeSetList responseAssertions = null;
		Object objResponseAssertions = null;
		try
		{
			objResponseAssertions = smConnService.readVariable(sessionId, "responseAssertions");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData responseAssertions)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        //No esta en el SM??
		}
		if (objResponseAssertions != null)
		{
			try {
				responseAssertions = (new ObjectMapper()).readValue(objResponseAssertions.toString(), AttributeSetList.class);
			} 
			catch (IOException e) 
			{
				log.error("Exception mapping responseAssertions "+e.getMessage());
				//e.printStackTrace();
				responseAssertions = new AttributeSetList();
			}
			log.info("manageIdpError: Reading responseAssertions");
		}
		else
		{
			responseAssertions = new AttributeSetList();
			log.info("manageIdpError: responseAssertions no encontrado");
			
		}
		responseAssertions.add(dsResponse);
		// Actualizo responseAssertions en el SM
		if (responseAssertions.size()>0)
		{
			ObjectMapper objMapper = new ObjectMapper();
			try
			{
				smConnService.updateVariable(sessionId,"responseAssertions",objMapper.writeValueAsString(responseAssertions));
			}
			catch (Exception ex)
			{
				String errorMsg= "Exception calling SM (updateVariable responseAssertions)  \n";
				errorMsg += "Exception message:"+ex.getMessage()+"\n";
				model.addAttribute("ErrorMessage",errorMsg);
				log.error(errorMsg);
		        return "acmError";
			}
		}
		
		
		/// Caso de enviar respuesta al SP (fin del todo)
		// Leo spMetadata
		EntityMetadata spMetadata = readSpMetadata(model, sessionId);
		
		//  Busco el endpoint para la redireccion
		// 
		String msName = "";
		String endPoint = null;
		if (spMetadata.getMicroservice() == null || spMetadata.getMicroservice().size()==0)
		{
			// ERROR
			String errorMsg= "Error getting microservice from spMetadata \n";
			
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		else
		{
			msName = spMetadata.getMicroservice().get(0);
			if(msName==null || msName=="")
			{
				msName = "SAMLms_0001";
			}
			log.info ("spMetadata msName:"+msName);
			
			MsMetadata microservice = null;
			for (int i =0; i<spMetadataList.size(); i++)
			{
				MsMetadata iMs = spMetadataList.get(i);
				if ( iMs.getMsId().equalsIgnoreCase(msName))
				{
					microservice = iMs;
					break;
				}
			}
			if (microservice==null)
			{
				String errorMsg= "Error getting microservice "+msName+" \n";
				
				model.addAttribute("ErrorMessage",errorMsg);
				log.error(errorMsg);
		        return "acmError";
			}
			//microservice.getPublishedAPI().get(0).getApiClass()
	//		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
	//											.filter(a->a.getApiClass()==ApiClassEnum.SP ).findAny();
			Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
					.filter(a->(((a.getApiClass()==ApiClassEnum.SP)||(a.getApiClass()==ApiClassEnum.GW)) && a.getApiCall()==ApiCallType.handleResponse) ).findAny();
	
			
			if (optPubApi.isPresent())
			{
				PublishedApiType pubApi = optPubApi.get();
				endPoint = pubApi.getApiEndpoint();
				log.info("En createAndSendResponseToSPms pubApi:"+pubApi.toString());
			}
		}
		
		// Creo un token para el SP
		String tokenToSPms = "";
		try
		{
			//tokenToSPms = smConnService.generateToken(sessionId,acmMsName,"SAMLms_0001");
			tokenToSPms = smConnService.generateToken(sessionId,acmMsName,msName);
		}
		catch (Exception ex)
		{
			String errorMsg= "responseAttributes: Exception calling SM (generateToken "+acmMsName+","+msName+")  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		//System.out.println("tokenToSPms"+tokenToSPms);
		
		String url = endPoint;
		model.addAttribute("msToken", tokenToSPms);
		model.addAttribute("UrlToRedirect", url);
		System.out.println("En manageIdpError -> Devuelvo idpRedirect "+url);
		       
		return "idpRedirect";
		
	}


	private String manageErrorInResponse(String sessionId, AttributeSet dsResponse, EntityMetadata dsMetadata,
			Model model) throws JsonParseException, JsonMappingException, IOException {
		// TODO Auto-generated method stub
		//return null;
		AttributeSetList responseAssertions = null;
		Object objResponseAssertions = null;
		try
		{
			objResponseAssertions = smConnService.readVariable(sessionId, "responseAssertions");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData responseAssertions)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        //No esta en el SM??
		}
		if (objResponseAssertions != null)
		{
			try {
				responseAssertions = (new ObjectMapper()).readValue(objResponseAssertions.toString(), AttributeSetList.class);
			} 
			catch (IOException e) 
			{
				log.error("Exception mapping responseAssertions "+e.getMessage());
				//e.printStackTrace();
				responseAssertions = new AttributeSetList();
			}
			log.info("manageAPResponse: Reading responseAssertions");
		}
		else
		{
			responseAssertions = new AttributeSetList();
			log.info("manageAPResponse: responseAssertions no encontrado");
			
		}
		AttributeSet spRequest = readSpRequest(model, sessionId);
		AttributeSet authenticationSet = readAuthenticationSet(sessionId);
		String errorMsg = "Error Code: "+dsResponse.getStatus().getCode()+" Error Message: "+dsResponse.getStatus().getMessage();
		return prepareAndGotoMultiUI(sessionId, model, spRequest, authenticationSet, responseAssertions, errorMsg);
	}


	// RespAtt05a. 			( se ha recibido respueta de IDP)
	//		RespAtt05a.1.	Se verifica si se ha recibido una respuesta correcta. Si hay sido una
	//						respuesta incorrecta(401,500 ->distinto de 200) se devuelve respuesta de error al SP ¿?
	//		RespAtt05a.2.	(Caso resp correcta) Se crea el idpResponse con lo recibido en dsResponse ¿?
	//		RespAtt05a.3.   Se pasa al modulo de consent y disco (gui)
	private String manageIdpResponse( String sessionId, AttributeSet dsResponse, 
									  EntityMetadata dsMetadata, Model model) throws JsonParseException, JsonMappingException, IOException
	{
		AttributeSet idpResponse = new AttributeSet();
		idpResponse = dsResponse;
		
		///		Añado idpResponse al SM
		//
		ObjectMapper objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"idpResponse",objMapper.writeValueAsString(idpResponse));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable idpResponse)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
	    // Leo responseAssertions¿?
		
		AttributeSetList responseAssertions= new AttributeSetList ();
		responseAssertions.add(idpResponse);
		
		objMapper = new ObjectMapper();
		try
		{
			smConnService.updateVariable(sessionId,"responseAssertions",objMapper.writeValueAsString(responseAssertions));
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (updateVariable responseAssertions)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		
//		String apEntityId = null;
//		try
//		{
//			apEntityId = (String) smConnService.readVariable(sessionId, "apEntityId");
//			log.info("Leida apEntityID="+apEntityId);
//			apEntityId = apEntityId.replaceAll("\"", "");
//			log.info("Leida apEntityID="+apEntityId);
//		}
//		catch (Exception ex)
//		{
//			log.info("manageIdpResponse: Excepcion al leer apEntityId");
//			System.out.println("RequestAttributes: Excepcion al leer apEntityId "+ex.getMessage());
//		}
		
//		if (apEntityId!=null && apEntityId!="")
//		{
//			log.info("manageIdpResponse: apEntityId founded "+apEntityId+" we return directly");
//			return createAndSendResponseToSPms(sessionId, model);
//		}
//		else
//		{
			//log.info("manageIdpResponse: apEntityId not founded we return go to MultiUI");
			log.info("manageIdpResponse: we go to MultiUI");
			AttributeSet spRequest = readSpRequest(model, sessionId);
			return prepareAndGotoMultiUI(sessionId, model, spRequest, idpResponse,responseAssertions, null);
//		}
		//createAndSendResponseToSPms
		//return "acmError";
	}

	private String manageAPResponse( String sessionId, AttributeSet dsResponse, 
									 EntityMetadata dsMetadata, Model model) throws JsonParseException, JsonMappingException, IOException 
	{
		
		AttributeSetList responseAssertions = null;
		Object objResponseAssertions = null;
		try
		{
			objResponseAssertions = smConnService.readVariable(sessionId, "responseAssertions");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData responseAssertions)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        //return "acmError";
	        //No esta en el SM??
		}
		if (objResponseAssertions != null)
		{
		responseAssertions = (new ObjectMapper()).readValue(objResponseAssertions.toString(), AttributeSetList.class);
		log.info("manageAPResponse: Reading responseAssertions");
		}
		else
		{
			responseAssertions = new AttributeSetList();
			log.info("manageAPResponse: responseAssertions no encontrado");
			
		}
		System.out.println("manageAPResponse: responseAssertions:"+responseAssertions.toString());
		
		
		if ( (dsResponse != null) &&
			 (dsResponse.getAttributes()!=null) &&
			 (dsResponse.getAttributes().size()>0)) //Compruebo que los attributos están
		{
			responseAssertions.add( dsResponse);// Añado la respuesta del AP a responseAssertions
		}
		// Actualizo responseAssertions en el SM
		if (responseAssertions.size()>0)
		{
			ObjectMapper objMapper = new ObjectMapper();
			try
			{
				smConnService.updateVariable(sessionId,"responseAssertions",objMapper.writeValueAsString(responseAssertions));
			}
			catch (Exception ex)
			{
				String errorMsg= "Exception calling SM (updateVariable responseAssertions)  \n";
				errorMsg += "Exception message:"+ex.getMessage()+"\n";
				model.addAttribute("ErrorMessage",errorMsg);
				log.error(errorMsg);
		        return "acmError";
			}
		}
		
		
//		AttributeSet spRequest= readSpRequest(model, sessionId);
//		log.info("manageAPResponse attributes:"+spRequest.toString());
//		AttributeSet authenticationSet = readAuthenticationSet(sessionId);
//		return prepareAndGotoMultiUI(sessionId, model, spRequest, authenticationSet,responseAssertions);
//		//return createAndSendResponseToSPms(sessionId, model);
		
		String apEntityId = null;
		try
		{
			apEntityId = (String) smConnService.readVariable(sessionId, "apEntityId");
			log.info("Leida apEntityID="+apEntityId);
			apEntityId = apEntityId.replaceAll("\"", "");
			log.info("Leida apEntityID="+apEntityId);
		}
		catch (Exception ex)
		{
			log.info("manageAPResponse: Excepcion al leer apEntityId");
			System.out.println("RequestAttributes: Excepcion al leer apEntityId "+ex.getMessage());
		}
		
		if (apEntityId!=null && apEntityId!="")
		{
			log.info("manageAPResponse: apEntityId founded "+apEntityId+" we return directly");
			return createAndSendResponseToSPms(sessionId, model);
		}
		else
		{
			log.info("manageAPResponse: apEntityId not founded we return go to MultiUI");
			AttributeSet spRequest = readSpRequest(model, sessionId);
			AttributeSet authenticationSet = readAuthenticationSet(sessionId);
			return prepareAndGotoMultiUI(sessionId, model, spRequest, authenticationSet,responseAssertions,null);
		}
		
		
		//return "acmError";
	}



	private AttributeSet readAuthenticationSet(String sessionId)
			throws IOException, JsonParseException, JsonMappingException {
		AttributeSet authenticationSet = null;
		Object objAuthSet = null;
		try
		{
			objAuthSet = smConnService.readVariable(sessionId, "authenticationSet");
		}
		catch (Exception ex)
		{
			log.info("RequestAttributes: Excepcion al leer authenticationSet");
			System.out.println("RequestAttributes: Excepcion al leer authenticationSet "+ex.getMessage());
		}
		if (objAuthSet!= null)
		{
			authenticationSet = (new ObjectMapper()).readValue(objAuthSet.toString(),AttributeSet.class);
		}
		return authenticationSet;
	}



	private String createAndSendResponseToSPms(String sessionId, Model model)
			throws IOException, JsonParseException, JsonMappingException {
		
		
		/// Caso de enviar respuesta al SP (fin del todo)
		// Leo spMetadata
		EntityMetadata spMetadata = readSpMetadata(model, sessionId);
		
		//  Busco el endpoint para la redireccion
		// 
		String msName = "";
		String endPoint = null;
		if (spMetadata.getMicroservice() == null || spMetadata.getMicroservice().size()==0)
		{
			// ERROR
			String errorMsg= "Error getting microservice from spMetadata \n";
			
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		else
		{
			msName = spMetadata.getMicroservice().get(0);
			if(msName==null || msName=="")
			{
				msName = "SAMLms_0001";
			}
			log.info ("spMetadata msName:"+msName);
			
			MsMetadata microservice = null;
			for (int i =0; i<spMetadataList.size(); i++)
			{
				MsMetadata iMs = spMetadataList.get(i);
				if ( iMs.getMsId().equalsIgnoreCase(msName))
				{
					microservice = iMs;
					break;
				}
			}
			if (microservice==null)
			{
				String errorMsg= "Error getting microservice "+msName+" \n";
				
				model.addAttribute("ErrorMessage",errorMsg);
				log.error(errorMsg);
		        return "acmError";
			}
			//microservice.getPublishedAPI().get(0).getApiClass()
	//		Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
	//											.filter(a->a.getApiClass()==ApiClassEnum.SP ).findAny();
			Optional<PublishedApiType> optPubApi = microservice.getPublishedAPI().stream()
					.filter(a->(((a.getApiClass()==ApiClassEnum.SP)||(a.getApiClass()==ApiClassEnum.GW)) && a.getApiCall()==ApiCallType.handleResponse) ).findAny();
	
			
			if (optPubApi.isPresent())
			{
				PublishedApiType pubApi = optPubApi.get();
				endPoint = pubApi.getApiEndpoint();
				log.info("En createAndSendResponseToSPms pubApi:"+pubApi.toString());
			}
		}
		
		// Creo un token para el SP
		String tokenToSPms = "";
		try
		{
			//tokenToSPms = smConnService.generateToken(sessionId,acmMsName,"SAMLms_0001");
			tokenToSPms = smConnService.generateToken(sessionId,acmMsName,msName);
		}
		catch (Exception ex)
		{
			String errorMsg= "responseAttributes: Exception calling SM (generateToken "+acmMsName+","+msName+")  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        return "acmError";
		}
		//System.out.println("tokenToSPms"+tokenToSPms);
		
		String url = endPoint;
		model.addAttribute("msToken", tokenToSPms);
		model.addAttribute("UrlToRedirect", url);
		System.out.println("En createAndSendResponseToSPms -> Devuelvo idpRedirect "+url);
		       
		return "idpRedirect";
	}






	@Override
	public String goToMultiUI(String sessionId, Model model) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	@Override
	public String readAllVariables(String session) throws Exception {
		// TODO Auto-generated method stub
		String response = "";
		//System.out.println("&&&&&&&LEO(requestAttributes) todas las variables de la sessionId:"+sessionId);
		if (session != "")
		{
			
//			for (final Room room : rooms) {
//				
//				
//			}
			HashMap<String, Object> vblesList = smConnService.readVariables(session);
			//for (Object variable: vblesList.)
			
			for ( HashMap.Entry<String,Object> obj : vblesList.entrySet())
			{
				response += ("Variable "+obj.getKey()+":"+obj.getValue().toString()+"\n");
			}
		
			//vblesList.forEach((st,obj) -> response.concat("Variable "+st+":"+obj.toString()+"\n")   );//System.out.println("Variable "+st+":"+obj.toString())
		}
		//System.out.println("&&&&&&&FIN(requestAttributes) de leer todas las variables de la sessionId:"+sessionId);
		System.out.println(response);
		return response;
	}

	//Private methods
	private void fillCMData()
	{
		log.info("fillCMData## Init");
		
		
//		EntityMetadata em =cmConnService.getConfiguration("LGW");
//		MsMetadataList msMtd = cmConnService.getMicroservicesByApiClass("ACM");
//		MsMetadataList msMtdAll = cmConnService.getAllMicroservices();
		
		//  Llamar a ConfigurationManager /metadata/attributes/{attrProfileId} donde
		//            profileid es eIDAS
		//           Obtenemos eIDAS.json que tiene attributtesList de donde con 
		//			  name o friendlyname obtenemos la info de los atributos eIDAS
		//fillAttTypeListEIDAS();
		//if (attTypeListEIDAS == null)
		{
			AttributeTypeList attTypeList = cmConnService.getAttributeSetByProfile("eIDAS",1);//[TODO] eIDAS en constante o variable 
			
			if (attTypeList != null)
			{
				attTypeListEIDAS = attTypeList;
				log.info("fillCMData##: Loaded attributeTypeList for eIDAS");
			//System.out.println("attTypeListEIDAS:"+attTypeListEIDAS.toString());
			}
			else
			{
				log.error("fillCMData##: attributeTypeList for eIDAS cannot be loaded");
			}
			
		}
		
		//   Averiguar idpMs ( en ppio puede estar en un variable configurable)
		//		 07a. Solicitar el idpMetadata.json al Configuration Manager llamando 
		//				a /metadata/externalEntities/{collectionID} donde
		//				collectionID es idp ¿?
		//				ó   /metadata/externalEntities/{collectionId}/{entityId}
		//			  Esto no sabemos si se hara cada ver o un daemon del ACM lo leera cada cierto tiempo
		//		 07b. Obtener la url del servicio /authenticate de lo recibido (lista de entityMetadata)
		//if (entityListIDP == null)
		{
			EntityMetadataList entMtd = cmConnService.getEntityMetadataSet("IdP",1); //[TODO] IdP en constante o variable
			
			
			if (entMtd != null)
			{
				log.info("fillCMData##: Loaded entityMetadataList for IdP");
				entityListIDP = entMtd;
				//System.out.println("%%%%%entityListIDP:"+entityListIDP.toString());
			}
			else
			{
				log.error("fillCMData##: attributeTypeList for IdP cannot be loaded");
			}
		}
		
		//if(idpMetadataList == null)
		{
			MsMetadataList msMtd = cmConnService.getMicroservicesByApiClass("IDP",1);
			if (msMtd !=null)
			{
				log.info("fillCMData##: Loaded microservices(MsMetadataList) for IdP");
				idpMetadataList =  msMtd;
				//System.out.println("%%%%%idpMetadataList"+idpMetadataList.toString());
			}
			else
			{
				log.error("fillCMData##: Microservices(MsMetadataList) for IdP cannot be loaded");
			}
		}
		
		
		MsMetadataList msMtd2 = cmConnService.getMicroservicesByApiClass("GW",1);
		//MsMetadataList gwMetadataList = cmConnService.getMicroservicesByApiClass("GW");
		if (msMtd2!=null)
		{
			log.info("fillCMData##: Loaded microservices(MsMetadataList) for GW");
			gwMetadataList = msMtd2;
		}
		else
		{
			log.error("fillCMData##: Microservices(MsMetadataList) for GW cannot be loaded");
		}
		
		
		//if(spMetadataList == null)
		{
			MsMetadataList msMtd3 = cmConnService.getMicroservicesByApiClass("SP",1);
			if (msMtd3!=null)
			{
				spMetadataList =  msMtd3;
				log.info("fillCMData##: Loaded microservices(MsMetadataList) for SP");
				//System.out.println("%%%%%spMetadataList"+spMetadataList.toString());
			}
			else
			{
				log.error("fillCMData##: Microservices(MsMetadataList) for SP cannot be loaded");
			}
			if (gwMetadataList!= null && gwMetadataList.size()>0)
			{
				if (spMetadataList == null)
				{
					spMetadataList = new MsMetadataList();
				}
				if (!spMetadataList.contains(gwMetadataList))
				{
					spMetadataList.addAll(gwMetadataList);
				}
			}
		}
		
		
		//if(apMetadataList == null)
		{
			MsMetadataList msMtd4 = cmConnService.getMicroservicesByApiClass("AP",1);
			if (msMtd4 != null)
			{
				apMetadataList =  msMtd4;
				log.info("fillCMData##: Loaded microservices(MsMetadataList) for AP");
				//System.out.println("%%%%%apMetadataList"+apMetadataList.toString());
			}
			else
			{
				log.error("fillCMData##: Microservices(MsMetadataList) for AP cannot be loaded");
			}
			
			if (gwMetadataList!= null && gwMetadataList.size()>0)
			{
				if (apMetadataList==null)
				{
					apMetadataList = new MsMetadataList();
				}
				if (!apMetadataList.contains(gwMetadataList))
				{
					apMetadataList.addAll(gwMetadataList);
				}
			}
		}
		
		//"AP", "rAP", "rGW"
		//if (entityListAP == null)
		{
			//log.info("Reading AP entity list");
			EntityMetadataList entMtd2= cmConnService.getEntityMetadataSet("AP",1); //[TODO] AP en constante o variable
			if (entMtd2 != null)
			{
				entityListAP = entMtd2;
				log.info("fillCMData##: Loaded EntityMetadataList for AP");
				//System.out.println("%%%%%entityListIDP:"+entityListIDP.toString());
			}
			else
			{
				log.error("fillCMData##: EntityMetadataList for AP cannot be loaded");
			}
		}
		
		//if (entityListRAP == null)
		{
			log.info("Reading RemoteAP entity list");
			EntityMetadataList entMtd3 = cmConnService.getEntityMetadataSet("rAP",1); //[TODO] rAP en constante o variable
			if (entMtd3 != null)
			{	
				entityListRAP = entMtd3;
				log.info("fillCMData##: Loaded EntityMetadataList for RAP");
				//System.out.println("%%%%%entityListRAP:"+entityListRAP.toString());
			}
			else
			{
				log.error("fillCMData##: EntityMetadataList for RAP cannot be loaded");
			}
			
		}
		
		//if (entityListRGW == null)
		{
			log.info("Reading RemoteGW entity list");
			EntityMetadataList entMtd4 = cmConnService.getEntityMetadataSet("rGW",1); //[TODO] rGW en constante o variable
			if (entMtd4!= null)
			{
				entityListRGW = entMtd4;
				log.info("fillCMData##: Loaded EntityMetadataList for RGW");
				//System.out.println("%%%%%entityListRGW:"+entityListRGW.toString());
			}
			else
			{
				log.error("fillCMData##: EntityMetadataList for RGW cannot be loaded");
			}
		}
		
		
		log.info("fillCMData## End");
	}
	
//	private void fillAttTypeListEIDAS() {
//		//if (attTypeListEIDAS == null)
//		{
//			AttributeTypeList attTypeList = cmConnService.getAttributeSetByProfile("eIDAS");//[TODO] eIDAS en constante o variable 
//			
//			if (attTypeList != null)
//			{
//			attTypeListEIDAS = attTypeList;
//			log.info("RequestAttributes: Loaded attributeTypeList for eIDAS");
//			//System.out.println("attTypeListEIDAS:"+attTypeListEIDAS.toString());
//			}
//			
//		}
//	}
	

	private EntityMetadata readSpMetadata(Model model, String sessionId)
			throws IOException, JsonParseException, JsonMappingException {
		EntityMetadata spMetadata = null;
		Object objSpMetadata = null;
		try
		{
			objSpMetadata = smConnService.readVariable(sessionId, "spMetadata");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        //return "acmError";
		}
		spMetadata = (new ObjectMapper()).readValue(objSpMetadata.toString(),EntityMetadata.class);
		log.info("readSpMetadata: Reading spMetadata");
		System.out.println("spMetadata:"+spMetadata.toString());
		return spMetadata;
	}


	private AttributeSet readSpRequest(Model model, String sessionId)
			throws IOException, JsonParseException, JsonMappingException {
		Object objSpRequest = null;
		AttributeSet spRequest = null;
		try
		{
			objSpRequest = smConnService.readVariable(sessionId, "spRequest");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        //return "classpath:/templates/idpRedirect"; 
	        //return "redirect:../idpRedirection";
	        //return "classpath:/templates/idpRedirect.html";
	        //return "acmError";
			
		}
		spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
		log.info("readSpRequest: Reading spRequest");
		System.out.println("spRequest:"+spRequest.toString() );
		return spRequest;
	}


	
	@Override
	public String requestAttributes2(String sessionId, Model model) throws Exception 
	{
		fillCMData();
		
		log.info("RequestAttributes: Token validated sessionId:"+sessionId);
		log.info(readAllVariables(sessionId));
		
		
		
		// ReqAtt02. Llamar al servicio de SessionManager /getSessionData con el sessionId 
		//			  y variableName="spRequest" (que es de tipo attributeSet (REQUEST))
		//  		 Obtener de SessionManagerResponse la variable spRequest 
		
		//AttributeSet spRequest = readSpRequest(model, sessionId); //falta la parte de error
		Object objSpRequest = null;
		AttributeSet spRequest = null;
		try
		{
			objSpRequest = smConnService.readVariable(sessionId, "spRequest");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spRequest)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        return "acmError";
			
		}
		spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
		log.info("RequestAttributes: Reading spRequest");
		//System.out.println("spRequest:"+spRequest.toString() );
		
		// ReqAtt03. Llamar al servicio de SessionManager /getSessionData con el sessionId 
		//			  y variableName="spMetadata" (que es de tipo EntityMetadata)
		//  		 Obtener de SessionManagerResponse la variable spMetadata 
		
		//EntityMetadata spMetadata = readSpMetadata(model, sessionId);
		EntityMetadata spMetadata = null;
		Object objSpMetadata = null;
		try
		{
			objSpMetadata = smConnService.readVariable(sessionId, "spMetadata");
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (getSessionData spMetadata)  \n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        //return "acmError";
		}
		spMetadata = (new ObjectMapper()).readValue(objSpMetadata.toString(),EntityMetadata.class);
		log.info("RequestAttributes: Reading spMetadata");
		//System.out.println("spMetadata:"+spMetadata.toString());
		
		//
		// ReqAtt04. Miro si esta en el SM la variable "authenticationSet" (AttributeSet)
		//
		AttributeSet authenticationSet = null;
		Object objAuthSet = null;
		try
		{
			objAuthSet = smConnService.readVariable(sessionId, "authenticationSet");
		}
		catch (Exception ex)
		{
			log.info("RequestAttributes: Excepcion al leer authenticationSet");
			System.out.println("RequestAttributes: Excepcion al leer authenticationSet "+ex.getMessage());
		}
		if (objAuthSet!= null)
		{
			authenticationSet = (new ObjectMapper()).readValue(objAuthSet.toString(),AttributeSet.class);
		}
		
		//
		// ReqAtt05. Miro si esta en el SM la variable "apEntityId"
		//
		String apEntityId = null;
		try
		{
			apEntityId = (String) smConnService.readVariable(sessionId, "apEntityId");
			log.info("Leida apEntityID="+apEntityId);
			apEntityId = apEntityId.replaceAll("\"", "");
			log.info("Leida apEntityID="+apEntityId);
		}
		catch (Exception ex)
		{
			log.info("RequestAttributes: Excepcion al leer apEntityId");
			System.out.println("RequestAttributes: Excepcion al leer apEntityId "+ex.getMessage());
		}
		
		if (apEntityId!=null && apEntityId!="")
		{	
			EntityMetadata apMetadata = getAPMetadata(apEntityId);
			//CASO C
			return prepareAndGotoAPms(sessionId, model, spRequest, spMetadata, apMetadata, authenticationSet);
			
		}
		
		//  NO TENEMOS apEntityId
		
		// ReqAtt06. Busco en la lista de atributos de spRequest si se piden attributos de Eidas
		AttributeSet idpRequest = new AttributeSet();
		
		for ( AttributeType attributeRequested : spRequest.getAttributes())
		{
			
			Optional<AttributeType> foundAtt=null;
			String friendlyName = attributeRequested.getFriendlyName();
			String name = attributeRequested.getName();
			System.out.println("### BUSCANDO att friendlyName:"+friendlyName);
			System.out.println("### BUSCANDO att name:"+name);
			if (friendlyName != null)
			{	
				foundAtt = attTypeListEIDAS.stream().filter(a ->a.getFriendlyName().equals(friendlyName) ).findAny();
			}
			else if (name !=null)
			{
				foundAtt = attTypeListEIDAS.stream().filter(a ->a.getName().equals(name) ).findAny();
			}
						
			if (foundAtt !=null && foundAtt.isPresent())
			{
				idpRequest.addAttributesItem( foundAtt.get());
				System.out.println("FoundAtt:"+foundAtt.get());
				System.out.println("RequestAtt:"+attributeRequested);
			}
			else
			{
				System.out.println("### NOT found");
			}
		}
		
		if (authenticationSet != null)
		{
			//Para la prueba
			AttributeSetList responseAssertions = null;
			Object objResponseAssertions = null;
			try
			{
				objResponseAssertions = smConnService.readVariable(sessionId, "responseAssertions");
				responseAssertions = (new ObjectMapper()).readValue(objResponseAssertions.toString(), AttributeSetList.class);
			}
			catch (Exception ex)
			{
				responseAssertions = null;
			}
			return prepareAndGotoMultiUI(sessionId, model, spRequest, authenticationSet,responseAssertions, null);
		}
		
		if (idpRequest.getAttributes()!=null && idpRequest.getAttributes().size()>0)
		{
			//CASO A Se piden atributos de EIDAS y redirecciono al IDP
			return prepareAndGotoIDPms( sessionId, model, spRequest, idpRequest);
		}
		else
		{
			String errorMsg= "ACM hasnt found in request attributes to request to the idp  \n";
			errorMsg += "spRequest: "+spRequest.toString();
			model.addAttribute("ErrorMessage",errorMsg);
			log.error(errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
			
		}
		
		
		return "acmError";
	}



	@Override
	public String responseAttributes3(String msToken) throws Exception {
		
		
		// Revisar token recibido
		//				 
		if (msToken.endsWith("="))
		{
			msToken = msToken.replace("=", "");
		}
		if (msToken.startsWith("msToken="))
		{
			msToken = msToken.replace("msToken=", "");
		}
		log.info("***after:<"+msToken+">");
		
		// Antes de empezar compruebo que tengo los datos del CM rellenos si no es así lo relleno
		fillCMData();
		
		
		// ReqAtt01. Llamar al servicio de SessionManager(SM) /validateToken con el msToken
		// 		     Obtener de SessionManagerResponse el sessionId -> se hace en SessionManagerConnService
		String sessionId="";
		try
		{
			sessionId = smConnService.validateToken( msToken);
		}
		catch (Exception ex)
		{
			String errorMsg= "Exception calling SM (validateToken) with token:"+msToken+"\n";
			errorMsg += "Exception message:"+ex.getMessage()+"\n";
			//model.addAttribute("ErrorMessage",errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	        
	        return "acmError";
		}
		if (sessionId == "")
		{
			String errorMsg= "Error response from SM (validateToken) with token:"+msToken+"\n";
			errorMsg += smConnService.getLastSMResponse();
			//model.addAttribute("ErrorMessage",errorMsg);
	        System.out.println("Devuelvo error "+errorMsg);
	       
	        return "acmError";
		}
		return sessionId;
	}



	@Override
	public String finishFromMulti(String sessionId, Model model) throws Exception {
		return createAndSendResponseToSPms(sessionId, model);
	}


}
