package eu.esmo.gateway.acm.services;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ACMms.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.httpclient.NameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.acm.domain.AttributeTypeList;
import eu.esmo.gateway.acm.domain.EntityMetadata;
import eu.esmo.gateway.acm.domain.EntityMetadataList;
import eu.esmo.gateway.acm.domain.MsMetadataList;
import eu.esmo.gateway.acm.domain.SessionMngrResponse;
//import eu.esmo.gateway.gw2gw.network_api.NetworkServiceImpl;
//import eu.esmo.gateway.gw2gw.network_api.NetworkServiceImpl;


@Service
public class ConfMngrConnServiceImp implements ConfMngrConnService
{
	private static final Logger log = LoggerFactory.getLogger(ConfMngrConnServiceImp.class);

		
//	@Value("${gateway.cm.protocol}")
//	private String protocol;
//	
//	@Value("${gateway.cm.server}")
//	private String server;
//	
//	@Value("${gateway.cm.port}")
//	private String port;
	
//	@Value("${gateway.cm.contextPath}")
//	private String contextPath;
	
	@Value("${gateway.cm.getAttributeProfilesPath}")
	private String getAttributeProfilesPath;
	
	@Value("${gateway.cm.getAttributeSetByProfilePath}")
	private String[] getAttributeSetByProfilePath;
		
	@Value("${gateway.cm.getExternalEntitiesPath}")
	private String getExternalEntitiesPath;
	
	@Value("${gateway.cm.getEntityMetadataSetPath}")
	private String[] getEntityMetadataSetPath;
	
	@Value("${gateway.cm.getEntityMetadataPath}")
	private String[] getEntityMetadataPath;
	
	@Value("${gateway.cm.getAllMicroservicesPath}")
	private String getAllMicroservicesPath;
	
	@Value("${gateway.cm.getMicroservicesByApiClassPath}")
	private String[] getMicroservicesByApiClassPath;
	
	private final String cmUrl;
	
	private HttpSignatureServiceImpl httpSigService = null;
	private NetworkServiceImpl network = null;
	
	
	@Autowired
    public ConfMngrConnServiceImp (ParameterService paramServ) throws UnrecoverableKeyException, KeyStoreException, FileNotFoundException, NoSuchAlgorithmException, CertificateException, InvalidKeySpecException, IOException 
	{
        cmUrl = paramServ.getParam("CONFIGURATION_MANAGER_URL");
        log.info("!!!!CM URL:["+cmUrl+"]");
        //this.keyStoreService = keyStoreServ;
        
        if (httpSigService== null)
		{
			createHttpSigService();
		}
		if (network == null)
		{
			network = new NetworkServiceImpl(httpSigService);
		}
	}
	
	
	@Override
	public EntityMetadata getConfiguration (String confId)
	{
		EntityMetadata result = null;
		
		try {
//			if (network == null)
//			{
//					network = new NetworkServiceImpl(keyStoreService);
//			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("confId", confId));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					"/cm/metadata/internal/{confId}",
					//getConfigurationPath[0] + "{" + getConfigurationPath[1] + "}", 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadata.class);
			}
			else
			{
				log.error("CMConnector: getConfiguration "+confId+" is NULL");
			}
			
		}
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getConfigurationPath[1], confId);
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		EntityMetadata result;
//		
//		try { 
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/internal/{confId}"
//												getConfigurationPath[0] + "{" + getConfigurationPath[1] + "}" , 
//												EntityMetadata.class, uriVariables);
//		}
		
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
	
	
	// /metadata/attributes
	@Override
	public List<String> getAttributeProfiles ()
	{	
		//RestTemplate restTemplate = new RestTemplate();
		List<String> result = null;
		String hostURL = cmUrl ;//+ contextPath; 
		String service = getAttributeProfilesPath;
		//
		// TO BE HANDLED THE ERRORS from ***restTemplate!!!
		//
		try {
			//result = restTemplate.getForObject( cmUrl + contextPath + getAttributeProfilesPath, List.class);
		    //response = network.sendGet(hostURL, service, urlParameters);
		    List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet(hostURL, service, urlParameters, 1);
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, List.class);
			}
			else
			{
				log.error( "CMConnector: getAttributeProfiles is NULL");
			}
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		return result;
	}
	
	//	/metadata/attributes/{attrProfileId}
	@Override
	public AttributeTypeList getAttributeSetByProfile(String profileId,int attempt) 
	{
		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add( new NameValuePair(getAttributeSetByProfilePath[1], profileId));
		//Map<String, String> uriVariables = new HashMap<>();
		//uriVariables.put(getAttributeSetByProfilePath[1], profileId);
		
		//RestTemplate restTemplate = new RestTemplate();
		AttributeTypeList result = null;
		String hostURL = cmUrl;// + contextPath; 
		String service = getAttributeSetByProfilePath[0] + "{"+ getAttributeSetByProfilePath[1] + "}";
		
		try {
//			result = restTemplate.getForObject( protocol + "://" + server + ":" + port + contextPath + 
//																	//"http://localhost:8080/cm/metadata/attributes/{attrProfileId}"
//															getAttributeSetByProfilePath[0] + "{"+ getAttributeSetByProfilePath[1] + "}", 
//															AttributeTypeList.class, uriVariables);
			//"http://localhost:8080/cm/metadata/attributes/{attrProfileId}"
//			result = restTemplate.getForObject( cmUrl + contextPath + 		
//						getAttributeSetByProfilePath[0] + "{"+ getAttributeSetByProfilePath[1] + "}", 
//						AttributeTypeList.class, uriVariables);
			
			String jsonResult = network.sendGetURIParams( hostURL, service, urlParameters,1);
						
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, AttributeTypeList.class);
			}
			else
			{
				if (attempt<2)
				{
					log.error("CMConnector: getAttributeSetByProfile "+profileId+" is NULL new ATTEMPT");
					return getAttributeSetByProfile( profileId,2);
				}
				log.error( "CMConnector: getAttributeSetByProfile "+profileId+"is NULL");
			}
						
		}
		catch (Exception e) {
			log.error("CM(getAttributeSetByProfile) exception", e);
			return null;
		}
		
		return result;
	}
	
	
	
	
	// /metadata/externalEntities
	@Override
	public List<String> getExternalEntities () {
		
		// returns available **collections**
		
		//RestTemplate restTemplate = new RestTemplate();
		
		List<String> result= null;
		String hostURL = cmUrl;// + contextPath; 
		String service = getExternalEntitiesPath;
		
		try {
//			result = restTemplate.getForObject( protocol + "://" + server + ":" + port + contextPath +
//														//"http://localhost:8080/cm/metadata/externalEntities/"
//														getExternalEntitiesPath, List.class);
			//"http://localhost:8080/cm/metadata/externalEntities/"
//			result = restTemplate.getForObject( cmUrl + contextPath + getExternalEntitiesPath, List.class);
			
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet(hostURL, service, urlParameters, 1);
			if (jsonResult != null) {
				log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, List.class);
			}
			else
			{
				log.error( "CMConnector: getExternalEntities is NULL");
			}
			
			
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	} 
	
	@Override
	public EntityMetadataList getEntityMetadataSet (String collectionId, int attempt)
	{
		
		EntityMetadataList result = null;
		
		try 
		{
			if (httpSigService== null)
			{
				createHttpSigService();
			}
			if (network == null)
			{
				network = new NetworkServiceImpl(httpSigService);
			}
		
//			if (network == null)
//			{
//					network = new NetworkServiceImpl(keyStoreService);
//			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("collectionId", collectionId));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					getEntityMetadataSetPath[0] + "{" + getEntityMetadataSetPath[1] + "}", 
					urlParameters, 1);
						
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadataList.class);
		        log.info("CMConnector: getEntityMetadataSet "+collectionId+" loaded");
			}
			else
			{
				if (attempt<2)
				{
					log.error("CMConnector: getEntityMetadataSet "+collectionId+" is NULL new ATTEMPT");
					return getEntityMetadataSet( collectionId,2);
				}
				log.error("CMConnector: getEntityMetadataSet "+collectionId+" is NULL");
			}
		
		}
		
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
//	// /metadata/externalEntities/{collectionId}
//	@Override
//	public EntityMetadataList getEntityMetadataSet (String collectionId)
//	{
//		String hostURL = cmUrl + contextPath; 
//		String service = getEntityMetadataSetPath[0] + "{" + getEntityMetadataSetPath[1] + "}";
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getEntityMetadataSetPath[1], collectionId);
//		
//		//RestTemplate restTemplate = new RestTemplate();
//		
//		EntityMetadataList result = null;
//		
//		try { 
//
////			//"http://localhost:8080/cm/metadata/externalEntities/{collectionId}"
////			result = restTemplate.getForObject( cmUrl + contextPath + getEntityMetadataSetPath[0] + 
////												"{" + getEntityMetadataSetPath[1] + "}" , 
////												EntityMetadataList.class, uriVariables);
//			
//			
//			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
//			
//			urlParameters.add(new NameValuePair("collectionId", collectionId));
//			String jsonResult = network.sendGetURIParams (hostURL, service,	urlParameters, 1);
//						
//			if (jsonResult != null) {
//				log.info("Result: "+ jsonResult);
//		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//		        result = mapper.readValue(jsonResult, EntityMetadataList.class);
//			}
//		}
//		catch (Exception e) {
//			log.error("CM(getEntityMetadataSet "+collectionId+") exception", e);
//			return null;
//		}
//		
//		return result;
//	}
	
	// /metadata/externalEntities/{collectionId}/{entityId}
	@Override
	public EntityMetadata getEntityMetadata (String collectionId, String entityId, int attempt)
	{
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getEntityMetadataPath[1], collectionId);
//		uriVariables.put(getEntityMetadataPath[2], entityId);
		
		//RestTemplate restTemplate = new RestTemplate();
		
		EntityMetadata result = null;
		String hostURL = cmUrl ;//+ contextPath; 
		String service = getEntityMetadataPath[0] + "{" + getEntityMetadataPath[1] + "}" + "/{" + getEntityMetadataPath[2] + "}";
		
		try {
//			result = restTemplate.getForObject(protocol + "://" + server + ":" + port + contextPath +
//														//"http://localhost:8080/cm/metadata/externalEntities/{collectionId}/{entityId}"
//														getEntityMetadataPath[0] + "{" + getEntityMetadataPath[1] + "}"+ "/{" + getEntityMetadataPath[2] + "}" , 
//														EntityMetadata.class, uriVariables);
			//"http://localhost:8080/cm/metadata/externalEntities/{collectionId}/{entityId}"
//			result = restTemplate.getForObject( cmUrl + contextPath + getEntityMetadataPath[0] + 
//												"{" + getEntityMetadataPath[1] + "}"+ "/{" + getEntityMetadataPath[2] + "}" , 
//												EntityMetadata.class, uriVariables);
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("collectionId", collectionId));
			urlParameters.add(new NameValuePair("entityId", entityId));
			String jsonResult = network.sendGetURIParams (hostURL, service,	urlParameters, 1);
						
			if (jsonResult != null) {
				log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadata.class);
			}
			else
			{
				if (attempt<2)
				{
					log.error("CMConnector: getEntityMetadata "+collectionId+" is NULL new ATTEMPT");
					return getEntityMetadata( collectionId,entityId,2);
				}
				log.error("CMConnector: getEntityMetadata collID:"+collectionId+" entID:"+entityId+" is NULL");
			}
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
	
	
	
	// /metadata/microservices
	@Override
	public MsMetadataList getAllMicroservices (){

		//RestTemplate restTemplate = new RestTemplate();
		String hostURL = cmUrl ;//+ contextPath; 
		MsMetadataList result = null;
		
		try {
//			result = restTemplate.getForObject( protocol + "://" + server + ":" + port + contextPath +
//														//"http://localhost:8080/cm/metadata/microservices/"
//														getAllMicroservicesPath, MsMetadataList.class);
			//"http://localhost:8080/cm/metadata/microservices/"
//			result = restTemplate.getForObject( cmUrl + contextPath + getAllMicroservicesPath, 
//												MsMetadataList.class);
			
			
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet (hostURL, getAllMicroservicesPath, urlParameters, 1);
			
			if (jsonResult != null) {
				log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, MsMetadataList.class);
			}
			else
			{
				log.error("CMConnector: getAllMicroservices is NULL");
		
			}
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}

		return result;
	}
	
	// /metadata/microservices/{apiClass}
	@Override
	public MsMetadataList getMicroservicesByApiClass (String apiClasses, int attempt)
	{
		// input like "SP, IDP, AP, GW, ACM, SM, CM"
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put("apiClass", apiClasses);
		
		//RestTemplate restTemplate = lsnew RestTemplate();
		String hostURL = cmUrl;//+ contextPath; 
		MsMetadataList result= null;
		
		try {
//			result = restTemplate.getForObject( protocol + "://" + server + ":" + port + contextPath +
//														//"http://localhost:8080/cm/metadata/microservices/{apiClass}"
//														getMicroservicesByApiClassPath[0] + "{" + getMicroservicesByApiClassPath[1] + "}" ,
//														MsMetadataList.class, uriVariables);
			//"http://localhost:8080/cm/metadata/microservices/{apiClass}"
//			result = restTemplate.getForObject( cmUrl + contextPath + getMicroservicesByApiClassPath[0] + 
//												"{" + getMicroservicesByApiClassPath[1] + "}" ,
//												MsMetadataList.class, uriVariables);
			
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("apiClass", apiClasses));
			String jsonResult = network.sendGetURIParams (hostURL, 
					getMicroservicesByApiClassPath[0] + "{" + getMicroservicesByApiClassPath[1] + "}", 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, MsMetadataList.class);
		        log.info("CMConnector: getMicroservicesByApiClass "+apiClasses+" is loaded");
			}
			else 
			{
				if (attempt<2)
				{
					log.error("CMConnector: getMicroservicesByApiClass "+apiClasses+" is NULL new ATTEMPT");
					return getMicroservicesByApiClass(apiClasses, 2);
				}
				log.error( "CMConnector: getMicroservicesByApiClass "+apiClasses+" is NULL");
			}
			
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
	private void createHttpSigService() throws KeyStoreException, FileNotFoundException, IOException,
	   NoSuchAlgorithmException, CertificateException, 
	   UnrecoverableKeyException, InvalidKeySpecException 
	{
		//[TODO] Cambiar para cada microservicio, el su
		String fingerPrint = "7a9ba747ab5ac50e640a07d90611ce612b7bde775457f2e57b804517a87c813b";
		ClassLoader classLoader = getClass().getClassLoader();
		//String path = classLoader.getResource("testKeys/keystore.jks").getPath();
		ClassPathResource resource = new ClassPathResource("testKeys/keystore.jks");
		log.info("En createHttpSigService resource:"+resource.getPath());
		InputStream certIS = resource.getInputStream();
		//File jwtCertFile = ResourceUtils.getFile("classpath:testKeys/keystore.jks");
		
		
		KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
		//File jwtCertFile = new File(path);
		//InputStream certIS = new FileInputStream(jwtCertFile);
		keystore.load(certIS, "keystorepass".toCharArray());
		
		Key signingKey = keystore.getKey("1", "selfsignedpass".toCharArray());
		
		httpSigService = new HttpSignatureServiceImpl(fingerPrint, signingKey);
	}
	
	
}