package eu.esmo.gateway.acm.services;
//package eu.esmo.httpSigs.lib.network;
/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of #component#.
ACMms is free software: you can redistribute it and/or modify it under the terms of #license#.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import org.apache.commons.httpclient.NameValuePair;

import eu.esmo.gateway.acm.domain.SessionMngrResponse;

/**
 *
 * @author nikos
 */
public interface NetworkService {

	
    public String sendGet(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt) throws IOException, NoSuchAlgorithmException;

    public String sendPostForm(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt) throws IOException, NoSuchAlgorithmException;

    public String sendPostBody(String hostUrl, String uri, Object postBody, String contentType, int attempt) throws IOException, NoSuchAlgorithmException;


	public SessionMngrResponse sendPostFormSMResponse(String hostUrl, String uri, 
													  List<NameValuePair> urlParameters, int attempt)
			throws IOException, NoSuchAlgorithmException;
	
	public SessionMngrResponse sendGetSMResponse(String hostUrl, String uri, 
												 List<NameValuePair> urlParameters, int attempt) 
			throws IOException, NoSuchAlgorithmException;

	public SessionMngrResponse sendPostBodySMResponse(String hostUrl, String uri, Object postBody, String contentType,
			int attempt) throws IOException, NoSuchAlgorithmException;

	String sendGetURIParams(String hostUrl, String uri, List<NameValuePair> urlParameters, int attempt)
			throws IOException, NoSuchAlgorithmException;


}
